(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"EnTing_project_atlas_1", frames: [[0,0,275,183]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.images = function() {
	this.initialize(ss["EnTing_project_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.images();
	this.instance.setTransform(-414.5,-301.7,3.0148,3.2973);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-414.5,-301.7,829.1,603.4);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.images();
	this.instance.setTransform(-414.5,-301.7,3.0148,3.2973);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-414.5,-301.7,829.1,603.4);


(lib.button_website = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgiAdQgOgLAAgRQAAgRANgMQANgLAWAAQAVAAAOALQANALABAVIg7AAQAAASANAAQAIAAAEgIIAgAEIgGAJQgEAEgFADQgMAGgQAAQgZAAgNgLgAgHgRQgCAEAAAHIAAABIAVAAIAAgCQAAgHgDgDQgDgFgFAAQgFAAgDAFg");
	this.shape.setTransform(83.775,71.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgHA0QgHgDgDgFIgDgGIgCgFIAAgUIAAgNIgKAAIAAgXIAKAAIAAgMIAmgSIAAAeIAQAAIAAAXIgQAAIAAAPQAAAHACADQABACAEAAQAEAAAFgCIAAAWQgDADgHACQgJACgHAAQgHAAgGgCg");
	this.shape_1.setTransform(74.35,69.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgaA3IAAgXIAIAAIAAgcIgIAAIAAgXIAuAAIAAAzIAHAAIAAAXgAgPgeQgGgEgBgGQABgHAGgEQAGgEAJABQAJgBAFAEQAHAFAAAFQAAAGgHAEQgGADgIAAQgJAAgGgCg");
	this.shape_2.setTransform(67.6,69.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgOAiIAAAFIgZAAIAAgYIAXAAQAJAJAJAAQALAAAAgEQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAgBgBAAQgCgBgJgCIgSgGQgJgCgFgEQgFgCgBgEQgCgDAAgGQAAgNAJgGQAJgFANAAQANAAAKAFIAAgEIAYAAIAAAWIgWAAQgJgIgKAAQgJAAAAAFQAAAAAAABQAAAAAAABQABAAAAAAQABABAAAAIAOADQAPADAIADQAIADAEAEQAEAFAAAIQAAANgKAGQgJAGgPAAQgNAAgJgFg");
	this.shape_3.setTransform(59.425,71.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgHAxIAAAEIgyAAIAAgXIAKAAIAAg8IgKAAIAAgYIAyAAIAAAlQAJgFAOAAQASgBAMALQAMAKAAAQQAAAJgDAIQgDAGgGAGQgLAMgRAAQgPAAgKgGgAgEAEQgEAEAAAHQAAARANABQANgBAAgRQAAgHgEgFQgDgDgGgBQgGAAgDAFg");
	this.shape_4.setTransform(48.025,69.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgiAdQgOgLAAgRQAAgRANgMQANgLAWAAQAVAAAOALQANALABAVIg7AAQAAASANAAQAIAAAEgIIAgAEIgGAJQgEAEgFADQgMAGgQAAQgZAAgNgLgAgHgRQgCAEAAAHIAAABIAVAAIAAgCQAAgHgDgDQgDgFgFAAQgFAAgDAFg");
	this.shape_5.setTransform(36.275,71.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAOA3IgOgqIgOAqIgiAAIgehTIgIAAIAAgaIA4AAIAAAaIgIAAIANAuIAQguIgIAAIAAgaIAvAAIAAAaIgIAAIAQAuIANguIgIAAIAAgaIAsAAIAAAaIgIAAIgeBTg");
	this.shape_6.setTransform(22.85,69.625);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AmtDNQhkAAAAhkIAAjRQAAhkBkAAINbAAQBkAAAABkIAADRQAABkhkAAg");
	this.shape_7.setTransform(53,69.7);

	this.text = new cjs.Text("", "15px 'Rockwell-ExtraBold'");
	this.text.lineHeight = 20;
	this.text.parent = this;
	this.text.setTransform(53,2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#9933FF").s().p("AgiAdQgOgLAAgRQAAgRANgMQANgLAWAAQAVAAAOALQANALABAVIg7AAQAAASANAAQAIAAAEgIIAgAEIgGAJQgEAEgFADQgMAGgQAAQgZAAgNgLgAgHgRQgCAEAAAHIAAABIAVAAIAAgCQAAgHgDgDQgDgFgFAAQgFAAgDAFg");
	this.shape_8.setTransform(83.775,71.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#9933FF").s().p("AgHA0QgHgDgDgFIgDgGIgCgFIAAgUIAAgNIgKAAIAAgXIAKAAIAAgMIAmgSIAAAeIAQAAIAAAXIgQAAIAAAPQAAAHACADQABACAEAAQAEAAAFgCIAAAWQgDADgHACQgJACgHAAQgHAAgGgCg");
	this.shape_9.setTransform(74.35,69.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#9933FF").s().p("AgaA3IAAgXIAIAAIAAgcIgIAAIAAgXIAuAAIAAAzIAHAAIAAAXgAgPgeQgGgEgBgGQABgHAGgEQAGgEAJABQAJgBAFAEQAHAFAAAFQAAAGgHAEQgGADgIAAQgJAAgGgCg");
	this.shape_10.setTransform(67.6,69.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#9933FF").s().p("AgOAiIAAAFIgZAAIAAgYIAXAAQAJAJAJAAQALAAAAgEQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAgBgBAAQgCgBgJgCIgSgGQgJgCgFgEQgFgCgBgEQgCgDAAgGQAAgNAJgGQAJgFANAAQANAAAKAFIAAgEIAYAAIAAAWIgWAAQgJgIgKAAQgJAAAAAFQAAAAAAABQAAAAAAABQABAAAAAAQABABAAAAIAOADQAPADAIADQAIADAEAEQAEAFAAAIQAAANgKAGQgJAGgPAAQgNAAgJgFg");
	this.shape_11.setTransform(59.425,71.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#9933FF").s().p("AgHAxIAAAEIgyAAIAAgXIAKAAIAAg8IgKAAIAAgYIAyAAIAAAlQAJgFAOAAQASgBAMALQAMAKAAAQQAAAJgDAIQgDAGgGAGQgLAMgRAAQgPAAgKgGgAgEAEQgEAEAAAHQAAARANABQANgBAAgRQAAgHgEgFQgDgDgGgBQgGAAgDAFg");
	this.shape_12.setTransform(48.025,69.65);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#9933FF").s().p("AgiAdQgOgLAAgRQAAgRANgMQANgLAWAAQAVAAAOALQANALABAVIg7AAQAAASANAAQAIAAAEgIIAgAEIgGAJQgEAEgFADQgMAGgQAAQgZAAgNgLgAgHgRQgCAEAAAHIAAABIAVAAIAAgCQAAgHgDgDQgDgFgFAAQgFAAgDAFg");
	this.shape_13.setTransform(36.275,71.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#9933FF").s().p("AAOA3IgOgqIgOAqIgiAAIgehTIgIAAIAAgaIA4AAIAAAaIgIAAIANAuIAQguIgIAAIAAgaIAvAAIAAAaIgIAAIAQAuIANguIgIAAIAAgaIAsAAIAAAaIgIAAIgeBTg");
	this.shape_14.setTransform(22.85,69.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{font:"15px 'Rockwell-ExtraBold'",lineHeight:19.65}},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.text,p:{font:"16px 'Rockwell-ExtraBold'",lineHeight:20.8}},{t:this.shape_7},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8}]},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,106,90.2);


(lib.button_next = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgRBQQgLgGgBgNIAAhkIgGAAIgDgBIgBgCIAAgHQAAAAAAgBQAAAAAAAAQAAgBABAAQAAAAAAAAIAEgBQALgBAMgHQAMgHACgIQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAABAAQAAAAABgBQAAAAABAAQABAAAAAAIALAAQAEAAAAAEIAAAWIAKAAQAGAAAAAEIAAAHQAAADgGAAIgKAAIAABkQABAFAHACQAEABABACIABAGIAAACIgFABg");
	this.shape.setTransform(65.15,18.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAABDIgEgBQgBAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBIABgGIAEgCQABAAAAAAQAAgBABAAQAAAAAAgBQABAAAAAAIgBgDIgLgUIgMAMQgHAIAAADQAAACAFABQAAAAABAAQABAAAAABQABAAAAABQAAAAAAABIAAADIgBAFIgEABIgfAAIgEgBIgBgCIAAgGQAAgBAAAAQABAAAAgBQABAAAAgBQABAAABAAQAFgCADgDIAegnIghg7QgCgDgEgCIgEgCQgBgBAAgGQAAgBABAAQAAgBAAAAQAAgBAAAAQAAAAAAAAIAFgBIA7AAIAEABQAAAAAAAAQABAAAAABQAAAAAAABQAAAAAAABIAAAEQAAACgDACQgDABAAADIAAABIALAUIAKgMIACgCQAGgHAAgCQAAAAAAgBQAAAAgBAAQAAgBgBAAQgBAAgBgBIgDgBIAAgGQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAAAIAFgBIAfAAIADABIABAFIgBAFIgDABQgEABgCADIggAoIAjA8QAAACAFACQAEACAAACIAAAGIgBACIgGABg");
	this.shape_1.setTransform(53.55,19.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgsAzQgVgQAAgiQAAghATgRQAUgSAfAAQAcAAARAPQAQAPAAAbIAAAJIhHAAIAAAnQAAAIAFAEQAEAFAIAAQAMAAAIgGQAHgHAAgLQAAgFACgCQACgBAKAAQAJAAACABQACABAAAFQAAAPgQALQgQAMgbAAQgdAAgWgRgAgFgtIAAAgIAUAAIAAggQAAgKgKAAQgKAAAAAKg");
	this.shape_2.setTransform(39.075,19.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAfBPIg+hZIAABEQAAAFAIACQAHACAAADIgBAIQAAABgFAAIgrAAQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAAAgBgBIAAgHQAAgDAEgBQAIgCAAgDIAAhzQAAgEgBgCQgBgCgFgBIgFgDQgCgBAAgEQAAgHAGAAIAtAAIA2BMIAAg4QAAgFgIgBIgGgDQgCgCAAgFQAAAAAAgBQAAgBAAAAQABgBAAAAQAAAAAAAAIAEgBIAtAAQAEAAAAAHIgBAEIgDACIgIACIgBAEIAACKg");
	this.shape_3.setTransform(24.125,18.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("AlEi4IKJAAQBkAAAABkIAACpQAABkhkAAIqJAAQhkAAAAhkIAAipQAAhkBkAAg");
	this.shape_4.setTransform(42.5,18.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AlEC5QhkAAAAhkIAAipQAAhkBkAAIKJAAQBkAAAABkIAACpQAABkhkAAg");
	this.shape_5.setTransform(42.5,18.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF99CC").s().p("AgRBQQgLgGgBgNIAAhkIgGAAIgDgBIgBgCIAAgHQAAAAAAgBQAAAAAAAAQAAgBABAAQAAAAAAAAIAEgBQALgBAMgHQAMgHACgIQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAABAAQAAAAABgBQAAAAABAAQABAAAAAAIALAAQAEAAAAAEIAAAWIAKAAQAGAAAAAEIAAAHQAAADgGAAIgKAAIAABkQABAFAHACQAEABABACIABAGIAAACIgFABg");
	this.shape_6.setTransform(65.15,18.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF99CC").s().p("AAABDIgEgBQgBAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBIABgGIAEgCQABAAAAAAQAAgBABAAQAAAAAAgBQABAAAAAAIgBgDIgLgUIgMAMQgHAIAAADQAAACAFABQAAAAABAAQABAAAAABQABAAAAABQAAAAAAABIAAADIgBAFIgEABIgfAAIgEgBIgBgCIAAgGQAAgBAAAAQABAAAAgBQABAAAAgBQABAAABAAQAFgCADgDIAegnIghg7QgCgDgEgCIgEgCQgBgBAAgGQAAgBABAAQAAgBAAAAQAAgBAAAAQAAAAAAAAIAFgBIA7AAIAEABQAAAAAAAAQABAAAAABQAAAAAAABQAAAAAAABIAAAEQAAACgDACQgDABAAADIAAABIALAUIAKgMIACgCQAGgHAAgCQAAAAAAgBQAAAAgBAAQAAgBgBAAQgBAAgBgBIgDgBIAAgGQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAAAIAFgBIAfAAIADABIABAFIgBAFIgDABQgEABgCADIggAoIAjA8QAAACAFACQAEACAAACIAAAGIgBACIgGABg");
	this.shape_7.setTransform(53.55,19.725);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF99CC").s().p("AgsAzQgVgQAAgiQAAghATgRQAUgSAfAAQAcAAARAPQAQAPAAAbIAAAJIhHAAIAAAnQAAAIAFAEQAEAFAIAAQAMAAAIgGQAHgHAAgLQAAgFACgCQACgBAKAAQAJAAACABQACABAAAFQAAAPgQALQgQAMgbAAQgdAAgWgRgAgFgtIAAAgIAUAAIAAggQAAgKgKAAQgKAAAAAKg");
	this.shape_8.setTransform(39.075,19.725);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF99CC").s().p("AAfBPIg+hZIAABEQAAAFAIACQAHACAAADIgBAIQAAABgFAAIgrAAQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAAAgBgBIAAgHQAAgDAEgBQAIgCAAgDIAAhzQAAgEgBgCQgBgCgFgBIgFgDQgCgBAAgEQAAgHAGAAIAtAAIA2BMIAAg4QAAgFgIgBIgGgDQgCgCAAgFQAAAAAAgBQAAgBAAAAQABgBAAAAQAAAAAAAAIAEgBIAtAAQAEAAAAAHIgBAEIgDACIgIACIgBAEIAACKg");
	this.shape_9.setTransform(24.125,18.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,87,39);


(lib.button_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgtArIAAgbIAMAAIAAgeIgMAAIAAgbIA0AAIAAAVQADgIAGgFQAGgGAGgBQAGgCAMgBIAAAmIgEAAQgOAAgGADQgHACgDAEQgCAFAAAHIANAAIAAAbg");
	this.shape.setTransform(73.125,14.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgnAhQgPgMAAgVQAAgSAPgNQAPgNAYAAQAYAAAPAMQAPAMABAZIhCAAQAAAUAOAAQAJAAAFgKIAkAFQgDAGgEAFQgFAEgGADQgMAHgSAAQgdAAgPgMgAgIgUQgDAFAAAHIAAACIAYAAIAAgDQAAgHgEgFQgDgEgGAAQgEAAgEAFg");
	this.shape_1.setTransform(61.7,14.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgVA+IgPgBQgOgDgHgCIAMgWQALAEASAAQALAAAFgDQAGgDACgEQADgFAAgHQgNAGgRAAQgSAAgNgLQgOgKAAgTQAAgUAOgMQANgMAVAAQAQAAALAHIAAgFIA2AAIAAAbIgKAAIAAAuQgBAPgDAJQgDAIgHAGQgHAGgMADQgKADgSAAIgPgBgAgPgfQgEAGAAAIQAAAIAEAFQAEAEAHAAQAHAAADgEQAFgFAAgIQAAgJgFgFQgDgFgHAAQgHAAgEAFg");
	this.shape_2.setTransform(48.6,16.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgtArIAAgbIAMAAIAAgeIgMAAIAAgbIA0AAIAAAVQADgIAGgFQAGgGAGgBQAGgCAMgBIAAAmIgEAAQgOAAgGADQgHACgDAEQgCAFAAAHIANAAIAAAbg");
	this.shape_3.setTransform(36.775,14.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgtAjQgKgIAAgXIAAgUIgKAAIAAgbIA2AAIAAAqQAAAIACAEQACAEAGAAQAHAAAGgEIAAgbIgMAAIAAgbIA4AAIAAA6IAKAAIAAAbIg2AAIAAgLQgRANgSAAQgNAAgJgJg");
	this.shape_4.setTransform(24.375,14.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhEA9IAAgdIAKAAIAAg/IgKAAIAAgdIBJAAQAWAAAMADQAMACAHAIQAHAIAAALQAAAKgHAGQgGAGgKADQANADAHAIQAHAIAAAKQAAANgIAIQgIAJgNADQgOACgaAAgAgKAiIAKAAQAJAAAFgCQAEgDAAgHQAAgGgEgDQgEgDgKAAIgKAAgAgKgLIAKAAQAKAAADgDQADgDAAgFQAAgEgDgEQgDgDgMAAIgIAAg");
	this.shape_5.setTransform(9.725,12.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#993366").s().p("AgtArIAAgbIAMAAIAAgeIgMAAIAAgbIA0AAIAAAVQADgIAGgFQAGgGAGgBQAGgCAMgBIAAAmIgEAAQgOAAgGADQgHACgDAEQgCAFAAAHIANAAIAAAbg");
	this.shape_6.setTransform(73.125,14.65);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#993366").s().p("AgnAhQgPgMAAgVQAAgSAPgNQAPgNAYAAQAYAAAPAMQAPAMABAZIhCAAQAAAUAOAAQAJAAAFgKIAkAFQgDAGgEAFQgFAEgGADQgMAHgSAAQgdAAgPgMgAgIgUQgDAFAAAHIAAACIAYAAIAAgDQAAgHgEgFQgDgEgGAAQgEAAgEAFg");
	this.shape_7.setTransform(61.7,14.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#993366").s().p("AgVA+IgPgBQgOgDgHgCIAMgWQALAEASAAQALAAAFgDQAGgDACgEQADgFAAgHQgNAGgRAAQgSAAgNgLQgOgKAAgTQAAgUAOgMQANgMAVAAQAQAAALAHIAAgFIA2AAIAAAbIgKAAIAAAuQgBAPgDAJQgDAIgHAGQgHAGgMADQgKADgSAAIgPgBgAgPgfQgEAGAAAIQAAAIAEAFQAEAEAHAAQAHAAADgEQAFgFAAgIQAAgJgFgFQgDgFgHAAQgHAAgEAFg");
	this.shape_8.setTransform(48.6,16.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#993366").s().p("AgtArIAAgbIAMAAIAAgeIgMAAIAAgbIA0AAIAAAVQADgIAGgFQAGgGAGgBQAGgCAMgBIAAAmIgEAAQgOAAgGADQgHACgDAEQgCAFAAAHIANAAIAAAbg");
	this.shape_9.setTransform(36.775,14.65);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#993366").s().p("AgtAjQgKgIAAgXIAAgUIgKAAIAAgbIA2AAIAAAqQAAAIACAEQACAEAGAAQAHAAAGgEIAAgbIgMAAIAAgbIA4AAIAAA6IAKAAIAAAbIg2AAIAAgLQgRANgSAAQgNAAgJgJg");
	this.shape_10.setTransform(24.375,14.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#993366").s().p("AhEA9IAAgdIAKAAIAAg/IgKAAIAAgdIBJAAQAWAAAMADQAMACAHAIQAHAIAAALQAAAKgHAGQgGAGgKADQANADAHAIQAHAIAAAKQAAANgIAIQgIAJgNADQgOACgaAAgAgKAiIAKAAQAJAAAFgCQAEgDAAgHQAAgGgEgDQgEgDgKAAIgKAAgAgKgLIAKAAQAKAAADgDQADgDAAgFQAAgEgDgEQgDgDgMAAIgIAAg");
	this.shape_11.setTransform(9.725,12.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,79.9,25.1);


(lib.button_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgjA+IAAgaIAOAAIAEgIIggg+IgGAAIAAgbIA4AAIAAAbIgIAAIAOAhIANghIgIAAIAAgbIAsAAIAAAbIgIAAIgvBgg");
	this.shape.setTransform(78.25,22.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgzAlQgIgIgBgLQABgMAKgHQAMgHASgBQAQAAAKAFIAAgCQAAgIgCgEQgBgDgEgCQgEgCgFAAQgLAAgGAHIgjgDQAHgNAMgFQANgEAYAAIAPAAIANACQAMACAFAFQAGAEACAGQACAFABAMIAAAXIALAAIAAAbIg3AAIAAgGQgLAIgTgBQgSAAgKgHgAgPAFQgDAEAAAFQAAAFAEADQADADAFAAQAHABAGgFIAAgQQgHgCgFAAQgGAAgEACg");
	this.shape_1.setTransform(66.1,20.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgdA9IAAgbIAJAAIAAhDIgJAAIAAgbIA0AAIAABeIAIAAIAAAbg");
	this.shape_2.setTransform(55.6,18.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhAA/IAAgaIALAAIAAhGIgLAAIAAgbIA3AAIAAAFQANgHAPAAQATAAANAMQAOANAAAUQAAATgNAMQgOAMgVgBQgQAAgKgGIAAASIAKAAIAAAagAgFggQgEAFAAAKQAAAJAEAEQAEAEAFABQAPgBAAgSQAAgSgOgBQgGAAgEAFg");
	this.shape_3.setTransform(44.625,22.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgnAhQgPgMAAgVQAAgSAOgNQAPgNAZAAQAXAAAQAMQAPANABAYIhDAAQABAUAOAAQAJAAAEgJIAlAEQgCAFgFAFQgFAFgGADQgNAHgSAAQgcAAgPgMgAgIgUQgDAFAAAHIAAACIAYAAIAAgDQAAgGgDgFQgEgFgFAAQgGAAgDAFg");
	this.shape_4.setTransform(31.6,20.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAbA9IgbgyIgNAAIAAAVIAJAAIAAAdIhDAAIAAgdIALAAIAAg/IgLAAIAAgdIBDAAIAQAAIAMABIAKACQANACAJAKQAHAJAAANQAAAJgEAIQgFAGgJAEIARAcIAJAAIAAAdgAgNgKIAFAAIANgBQAEAAADgDQACgDABgFQgBgEgCgDQgDgDgEgBIgOAAIgEAAg");
	this.shape_5.setTransform(17.9,18.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AmAC5QhkAAAAhkIAAipQAAhkBkAAIMBAAQBkAAAABkIAACpQAABkhkAAg");
	this.shape_6.setTransform(48.475,18.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CC6699").s().p("AgjA+IAAgaIAOAAIAEgIIggg+IgGAAIAAgbIA4AAIAAAbIgIAAIAOAhIANghIgIAAIAAgbIAsAAIAAAbIgIAAIgvBgg");
	this.shape_7.setTransform(78.25,22.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CC6699").s().p("AgzAlQgIgIgBgLQABgMAKgHQAMgHASgBQAQAAAKAFIAAgCQAAgIgCgEQgBgDgEgCQgEgCgFAAQgLAAgGAHIgjgDQAHgNAMgFQANgEAYAAIAPAAIANACQAMACAFAFQAGAEACAGQACAFABAMIAAAXIALAAIAAAbIg3AAIAAgGQgLAIgTgBQgSAAgKgHgAgPAFQgDAEAAAFQAAAFAEADQADADAFAAQAHABAGgFIAAgQQgHgCgFAAQgGAAgEACg");
	this.shape_8.setTransform(66.1,20.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CC6699").s().p("AgdA9IAAgbIAJAAIAAhDIgJAAIAAgbIA0AAIAABeIAIAAIAAAbg");
	this.shape_9.setTransform(55.6,18.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CC6699").s().p("AhAA/IAAgaIALAAIAAhGIgLAAIAAgbIA3AAIAAAFQANgHAPAAQATAAANAMQAOANAAAUQAAATgNAMQgOAMgVgBQgQAAgKgGIAAASIAKAAIAAAagAgFggQgEAFAAAKQAAAJAEAEQAEAEAFABQAPgBAAgSQAAgSgOgBQgGAAgEAFg");
	this.shape_10.setTransform(44.625,22.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CC6699").s().p("AgnAhQgPgMAAgVQAAgSAOgNQAPgNAZAAQAXAAAQAMQAPANABAYIhDAAQABAUAOAAQAJAAAEgJIAlAEQgCAFgFAFQgFAFgGADQgNAHgSAAQgcAAgPgMgAgIgUQgDAFAAAHIAAACIAYAAIAAgDQAAgGgDgFQgEgFgFAAQgGAAgDAFg");
	this.shape_11.setTransform(31.6,20.75);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CC6699").s().p("AAbA9IgbgyIgNAAIAAAVIAJAAIAAAdIhDAAIAAgdIALAAIAAg/IgLAAIAAgdIBDAAIAQAAIAMABIAKACQANACAJAKQAHAJAAANQAAAJgEAIQgFAGgJAEIARAcIAJAAIAAAdgAgNgKIAFAAIANgBQAEAAADgDQACgDABgFQgBgEgCgDQgDgDgEgBIgOAAIgEAAg");
	this.shape_12.setTransform(17.9,18.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_6},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7}]},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,97,37);


(lib.Group_89 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_89, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_88 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E7DFD9").s().p("AABAJQAXgnAshRQg0B5hTBmQAigrAig8g");
	this.shape.setTransform(7.7875,11.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_88, new cjs.Rectangle(1,0,13.6,22.4), null);


(lib.Group_87 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E7DFD9").s().p("AgjArQAfgzAagiIAOA7QgMgCgYAPQgVANgLAAIgDAAg");
	this.shape.setTransform(3.6,4.2871);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_87, new cjs.Rectangle(0,0,7.2,8.6), null);


(lib.Group_86 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_86, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_85 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_85, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_84 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_84, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_83 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_83, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_82 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_82, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_81 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_81, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_80 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_80, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_79 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E7DFD9").s().p("AhEABQhEgBgyAEQBLgIBcABQArAACjAFQg2ADgrAAIiegEg");
	this.shape.setTransform(22.7375,0.4491);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_79, new cjs.Rectangle(4.1,0,37.4,0.9), null);


(lib.Group_78 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_78, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_77 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_77, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_76 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_76, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_75 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_75, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_74 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_74, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_73 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_73, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_72 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_72, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_71 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_71, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_70 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_70, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_69 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_69, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_68 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_68, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_67 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_67, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_66 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_66, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_65 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E7DFD9").s().p("AgEgDIAMgIQgIALgHAMg");
	this.shape.setTransform(0.825,1.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_65, new cjs.Rectangle(0,0,1.7,2.4), null);


(lib.Group_64 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_64, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_63 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_63, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_62 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_62, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_61 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_61, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_60 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E7DFD9").s().p("AgHgCIBOh3IhDCCQgzBkgXANQAUg5ArhDg");
	this.shape.setTransform(7.125,12.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_60, new cjs.Rectangle(0,0,14.3,24.4), null);


(lib.Group_59 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_59, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_58 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_58, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_57 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_57, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_56 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_56, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_55 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_55, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_54 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_54, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_53 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_53, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_52 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_52, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_51 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_51, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_50 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_50, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_49 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_49, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_48 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_48, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_47 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_47, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_46 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_46, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_45 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_45, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_44 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_44, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_43 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_43, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_42 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_42, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_33 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AhZBRQgigOArgdIgIAEQAQglAbglQAjgyAXgFQgBAIgKAWQgHATgBAMIAMgKIAMgLIgEAOIANgGQAKgEAEgEIgCADQgBABAAAAQAAABAAAAQAAAAAAAAQAAABAAAAQAIgFAVgSQATgPAIgFIgSAVQgLAMgEAKIAOgCQAHgCAGgEQgZARgVAeQASACAQgNQgEADgCAEIgEAHQATgCAUABQgHAIgNAGIgYAMQgJAFgiAZQgaAUgTAHQgOAFgOAAQgRAAgRgHg");
	this.shape.setTransform(10.4117,8.8395);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_33, new cjs.Rectangle(-0.1,0,21,17.7), null);


(lib.Group_32 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_32, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_31 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_31, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_30 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_30, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_29 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_29, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_28 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_28, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_27 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_27, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_26 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_26, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_25 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_25, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_24 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_24, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_23 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_23, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_22, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_21 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_21, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_20 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_20, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_19, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_18, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_17, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_16_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_16_0, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AgoBLQhLgIgogBQg6gBg0AJQgeglgVggQBNgeBXgVQCCgeB8AAQBxAABmAZQgzAkg8AfQhbAkhnAYQgNABgPAAg");
	this.shape.setTransform(31.675,7.725);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_16, new cjs.Rectangle(0,0,63.4,15.5), null);


(lib.Group_15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_15, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_14, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_13_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_13_0, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AgCECQhrgRhzglQgcgMgcgRIgDgCQg7g7hOgWQgbgOgegHIgEiFQgBhSAOgsQgDAKEQATQEMATAqgEQBagHA0gNQA5gOAhgRQAsgXAWgnQA1B5AUBPQhpA5hCBtIgKAQQgdAjgfAdQgdAVgkAUQgmAOgoAKQgmAEgtAAIgRAAg");
	this.shape.setTransform(48.1677,25.8083);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_13, new cjs.Rectangle(0,0,96.4,51.6), null);


(lib.Group_12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_12, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_11_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AhABNQg0gmAAg1QAAhWBWgXQA2gOBdAMQgogEg0AXQg5AZgOAjQgQAsAfA2QAUAjAqAtQhCghgdgWg");
	this.shape.setTransform(11.6749,13.1369);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_11_1, new cjs.Rectangle(0,0,23.4,26.3), null);


(lib.Group_11_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_11_0, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AhcDFQg4gEhWgdQhjgjgngHQgRgDgHgDQgJgDgEgFQgEgEgHgSQgDgHgshHQgdgtAIgiIACgLQACgHgBgEQgBgJgJgJIgPgPQgLgMgCgSQgCgRAIgPQAGgLAJgGQAnAuAxAlQBmBNAtAcQBWA3BLAVQCSArC/hKQC5hHBgh/IAKgNIgBAJQgCAXAEAxQADAsgFAYQgGAdgPAXQgUAggpAiQgQAOg5ApQhSA9iMAGIgPAAQg2AAingJg");
	this.shape.setTransform(52.365,20.6398);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_11, new cjs.Rectangle(0,0,104.8,41.3), null);


(lib.Group_10_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AiQAXQACgfALgPQAagkA+gKQA0gIA0ASQA0ATAiAoQgfgcgrgKQgrgKgoALQgpAKghAgQgSATgmArIgGAGIACgyg");
	this.shape.setTransform(14.675,7.2412);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_10_0, new cjs.Rectangle(0,0,29.4,14.5), null);


(lib.Group_10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_10, new cjs.Rectangle(0,0,0,0), null);


(lib.Group_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("Ah9BtQgsgfgMgxQgKglARg7QAShCAmACIgTAmQgLAWgCASQgEAbAMAZQAMAYAXAJQAXAIAggMQATgHAjgRQAugQAyAHQAyAHAmAeQgwgIhBAvIgyAkQgcASgaAFQgMACgLAAQgkAAgjgXg");
	this.shape.setTransform(18.4764,13.2348);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_9, new cjs.Rectangle(-0.1,0,37.2,26.5), null);


(lib.Group_8_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AiMA6QgggUgRggQgSgiAGghIgDAFQgEgKAKgIQAKgIALABQAOACAYATQAmAdAvAOQAuAOAvgEQAvgDAsgWQAsgVAggiQACAqgVAnQgVAngkAWQgyAghTABIgKAAQhPAAgwgeg");
	this.shape.setTransform(20.6347,8.8059);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_8_1, new cjs.Rectangle(0,0,41.3,17.6), null);


(lib.Group_8_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("ACvLLQhhAAhugDQjkgLjpgiQlAgvkuhZIgBAAIgMgEIgbgWQhAiggUkEQgEg1gDhKIgEiqQgFijAMhdQALhbAbhKQANgkAWguQBAA8BfAVQBYAVBfgRQAegFAXgGQB4DvC3DGQCrC4D1CnQD/CvEfBwIAGACIhPAUQgKADgYAEIgjAGIggAEIgdACIgXACIhdAEQggABgpgEQg3gFgygNQgZgGgggLQgbgJgbgMIgNgFIgCgBIgEABIgBAAIgIACQgdALgFAVQgEARANAUIAFAEQAlARAeALQAgAMAnAKQBAAQBCAFIAtACIBegCIAmgHQAngJAcgIIAOgEQAugOAmgSQAVgJABgCIAegRIAAgBIAMgIIABAAIACgCIAJgGIABgBIAJgIQFlCEFxAUIjLAmIAAAAItpBMgAt+B5Qg4APgdAiQggAoATAwQAGAOAKAOQAJAOAOAKQAZAUAjAGIABAAIACABQATACANgBQAlgBAggRQAigSASgeQASghgGglQgGgngdgWQgagSglgFQgMgCgMAAQgXAAgYAFgAssjXQhbAIhQAnQhTApgTAzQgVA6BLAyIAKAHQAjAVBAAOIAvAIQAmAHByAXQBmALAqgtIARgWQAXgogNg1QgJgqgbgpQgagngigYIgMgIQgrgahFAAQgTAAgVACg");
	this.shape.setTransform(125.2617,71.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_8_0, new cjs.Rectangle(0,0,250.5,143.1), null);


(lib.Group_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AhmB4QhAgMglgYQgqgbgZg1QhFiPCQAOQAkAEBbAVQBNASAagCQAQgBA+gIQA/gIAmACQB2AIg6BlQgnBGiEAfQhGAQg8AAQgnAAgkgHg");
	this.shape.setTransform(29.4103,12.6821);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_8, new cjs.Rectangle(0.1,0,58.699999999999996,25.4), null);


(lib.Group_7_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AACCaQgOgBgLgKQgMgLABgOQABgMAQgQQBBg/AZglQAthEhAgnQgagQgrgFQgzgIg2AFIAogIQAkgFAcABQBEADA6A5QA+A+gXBCQgSA1hLAwQgfASgVAAIgCAAgAibiJIAjgEIgWAFg");
	this.shape.setTransform(15.5612,15.4364);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_7_0, new cjs.Rectangle(0,0,31.1,30.9), null);


(lib.Group_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("Ag9AaQgQjyBSjeIgWgDIAjglQgiHhBQHcQhtjRgQj0g");
	this.shape.setTransform(6.4207,47.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_7, new cjs.Rectangle(0,0,12.9,95.8), null);


(lib.Group_6_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AAKBQIhTAHQAMgSAUgLQASgLAVgCIh4gDIB2gsIhjgPIB3gNIhjgqIB0AFIiSgqQARAEAogFQAsgFASAFQAmAJAyAgIAcATQghALgLAwIgIAoQgGAWgKANQgOAPgYAHQgQAFgdADg");
	this.shape.setTransform(12.25,11.381);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_6_0, new cjs.Rectangle(0,0,24.5,22.8), null);


(lib.Group_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AgnCuQgGirALhdQARiGA6h1IABABQgWAugNAkQgaBKgLBbQgMBdAFCiIAECqIABAKIgHiog");
	this.shape.setTransform(4.2721,34.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_6, new cjs.Rectangle(0.1,0,8.4,68.3), null);


(lib.Group_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AA8AyQgSAXgYACIAAgPQAAgLACgFIgXATQgOAKgMACQAFgWAKgYIgXAPQgNAJgKACQgBgLAGgPIANgYIgtAYQgbAPgSAHQACgVAcgYQAIgGAlgaQgNAAgZAIQgaAHgOAAQBhhKAlAIIAAgJIAHAMIgHgDQABANAMAKIAfAUIAtAkQAeAaASAAQgKANgcARQgmAYgGAFQgBgYAHgNg");
	this.shape.setTransform(13.575,8.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_5, new cjs.Rectangle(0,0,27.2,17.4), null);


(lib.Group_4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("Ag1BcQgZgGgRgNQgOgCgJgZIgCgGQgEgPgDgWQgGgxAFgxQAcA5ATAQQAFgSgKgSQAGAJAJAVQAJASAMAGQAGgLAEgXQAEgYAFgKQAGAoAJAUIANgbQAHgQAHgJIgDAhQAAATAHAMQAKgNAIgaQAKgeAFgKQgGAuACA4QAPgKARgZIAYgsQgKAWgDAXQAPgCASgoQAHgQAEgOQgNA4gJAbQgTA9g3AZQgYAKgbAAQgSAAgTgEg");
	this.shape.setTransform(13.0786,11.178);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_4_1, new cjs.Rectangle(0,1.6,26.2,19.2), null);


(lib.Group_4_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("ABfCkQhwgXgngHIgugIQhAgOgjgVIgLgHQhKgzAVg5QATgzBTgpQBPgnBagIQBigJA3AhIAMAIQAhAYAbAnQAbApAJApQAMA2gXAoIgQAWQgiAkhJAAQgSAAgUgCg");
	this.shape.setTransform(27.0892,16.5876);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_4_0, new cjs.Rectangle(0,0,54.2,33.2), null);


(lib.Group_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AgwkKIgCAMIgBghQBGCDAXCVQAXCUgcCTQgBkdhUkNg");
	this.shape.setTransform(5.1936,28.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_4, new cjs.Rectangle(0,0,10.4,57.5), null);


(lib.Group_3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AhbBjQgZgVgIghQgJgjAOgcQATgkBdgtQBRgnAZARQAAAHgFAIQgGAKgMAHIAFAAQgRAHgJACQATAJAQgCIgjAIQgWAFgNAFQAOAEApAIQAiAGATAIQgpAMgvgBQAMAEAQAAIAYAAQhDADg/ARIAiAMQAWAIAMAGQgJAFgRgBIgbgDQALAFAWAHQATAIAKAKIgrACQgbACgPAFQATAPAoAIIBBAOQg2ARggABIgFAAQguAAgggcg");
	this.shape.setTransform(12.8144,12.5711);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_3_1, new cjs.Rectangle(0,-0.1,25.7,25.400000000000002), null);


(lib.Group_3_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E7DFD9").s().p("AAPDgIARhtIAHg3QAEgngGgUQgGgTgUgOQgQgMgXgFQgfgHgUARQgHAGgHANIgNAUQgQAWgfAEQgdAEgYgPQgYgPgLgaQgKgaAFgYQAFgZATgKQAVgLAgAOQAGADAQAKQANAIAIACQAcAHAEgcQgCgjABgMQADhmAngVQAogYBUBAQBjBLAoBAQA2BXgWBoQgSBZg1AqQgbAWg1AOQg9AOgaAIg");
	this.shape.setTransform(24.8628,28.3576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_3_0, new cjs.Rectangle(0,0,49.8,56.7), null);


(lib.Group_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AhlDrQhEgSgfg3QAiAbAxgEQAvgEAmgcQBkhKA+hlQBBhqAGhxQgFCJgRBUQgcCKhABEQgaAcgmAOQgjAOgmAAQgZAAgagHg");
	this.shape.setTransform(20.125,25.0861);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_3, new cjs.Rectangle(0,0.9,40.3,48.4), null);


(lib.Group_2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AhIB7QgqgcgbgpQgcgrACgnQAEgtAsgcIgwATQAegSAxgiQAqgXAwAIQA9ALAyA9QAuA5AJBAQgFgHgIgSIgNgYQgMgTgXgRQgbgSgOgLQgEAKABAPIACAaIgMgMQgIgHgDgEQACAUAMAQQgJgEgQgNQgPgMgKgDQABAMAGAOIANAXQgYgIgagWQABAPAIAMQAHAOAKAJQgNgEgUgKIghgRQAKAaAOAVQgNgBgQgHQgIgEgSgLQgHAuBvBSQgmAAgrgdg");
	this.shape.setTransform(16.7649,15.2121);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2_1, new cjs.Rectangle(0,0,33.6,30.4), null);


(lib.Group_2_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AhIBIQhCgFhAgQQgogKgfgLQgegLgmgRIgEgEQgNgUAEgRQAFgVAcgKIAJgDIAAAAIAFgBIACABIANAGQAaALAcAKQAfAKAZAHQA0AMA2AGQApADAgAAIA2gCIBagGIAggEIAjgHQAZgDAKgEIBOgUIAiANIABABIgKAIIgBABIgJAGIgCACIAAAAIgNAIIAAABIgeAQQAAACgVAJQgmASguANIgPAFQgcAIgmAJIgmAGIhdADIgugDg");
	this.shape.setTransform(35.5529,7.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2_0, new cjs.Rectangle(0,0,71.2,14.9), null);


(lib.Group_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AgZBdQgwgFghgJQgrgMgegWQgjgZgQglQgSgpAMglQAgAwAxAiQA/AqBIAJQBHAJBHgbQBHgZAxg2QACAqgdAlQgaAkgqATQgvAVhGAAQgaAAgdgDg");
	this.shape.setTransform(25.2856,12.1307);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2, new cjs.Rectangle(1.1,2.6,48.4,19.099999999999998), null);


(lib.Group_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AheAGQAPgrAfgSQAHgEAHgDQAmgRAkgDQAzgEAMAgIg6ApQgjAYgWgWQgBAFgGAIIgIAOQgEgGgDgLQgGAFgHAQQgIAQgFAFQAAgEgBgDIgTAmIAEghQgIAYgMAUQgOgiAQgrg");
	this.shape.setTransform(10.3108,8.3031);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_1, new cjs.Rectangle(0,0,20.7,16.7), null);


(lib.Group_1_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CECBC7").s().p("AA5CEIhug7QhFgngUgpQgNgdAYgfQAPgVAjgYQANgJANgFQAVgHAUADQAKACARAIQAwAUATADQAkAHAggTQgHAEgGAtIgGA2QgFAhgEAQQgGAZgMAWIgDAqg");
	this.shape.setTransform(14.7435,13.2167);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_0, new cjs.Rectangle(0,0.1,29.5,26.299999999999997), null);


(lib.Group_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AghEiQgegJgVgUIAGAIIgJgKIADACQhXhzgYiTQgZiaAyiNIAEAZIgBgFIABA7IAGBpQAGA7AOAqIAVBGQANArANAbQAVAsAuAdIATALQALAGAIgFQAFgDAEgOQAHgXAEglIAHg8IAZBrIAOhCIAiBLIBai7QAKBjghBJQgTApggAeQgiAggpALQgUAFgUAAQgWAAgYgHg");
	this.shape.setTransform(20.4185,29.7324);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1, new cjs.Rectangle(0,0,40.9,59.5), null);


(lib.Group_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("AgcBtIgCAAIgBAAQgjgHgZgTQgOgLgJgNQgKgOgGgOQgTgvAggoQAdgjA4gOQAjgIAjAEQAlAFAaATQAdAVAGAnQAGAlgSAgQgSAfgiASQggARglABIgEAAQgLAAgQgCg");
	this.shape.setTransform(13.7578,11.1263);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_0, new cjs.Rectangle(0,0,27.6,22.3), null);


(lib.Group = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333555").s().p("Ag3HSQgngHgvgRIgdgNIAQADQApADAhgWQAfgUASglQARgiAEgpQAEgigGgrQgDgagLgyIBGD3IAKgtQAHgbAGgRIAGgVQADgMgBgJQgDgSgFgLIAHAHQAHAJADAHQAFALAAAXIAEAPIACAJIACgIIAFgOQAKgjADgXQADgXgDgeIgEgPIgDgKIACADIAFAIQAHAUAFAbQAHAvgKAUQAEgCADgRQAKgkABgcQABghgGgQIgIgQQgDgKADgIQAHABAFAJIAHANIAKARQAFAJgBAJQAFgbgEgkIgIg/Igrn0QBXEgAVEoQAEA3gBAkQgBAxgJAoQgLAugYAlQgZApgkAXQgyAghCAAQgaAAgegGgAjfGWIADgHQAHAJAKAHIgUgJgAA+DQIgDgIQgCgEgDgDQAHAEAGASIgFgHg");
	this.shape.setTransform(22.3531,47.1798);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(0,0,44.7,94.4), null);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.button_2();
	this.instance.setTransform(-44.45,-15);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.button_2(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmoDIQhkAAAAhkIAAjHQAAhkBkAAINRAAQBkAAAABkIAADHQAABkhkAAg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(-52.4,-20,104.9,40), null);


(lib.Trunk = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group();
	this.instance.setTransform(188.1,155.9,0.7929,0.7929,0,0,0,24.7,49.3);
	this.instance.alpha = 0.2813;
	this.instance.compositeOperation = "overlay";

	this.instance_1 = new lib.Group_1();
	this.instance_1.setTransform(36.55,173.05,0.7929,0.7929,0,0,0,22.5,31.9);
	this.instance_1.alpha = 0.3281;
	this.instance_1.compositeOperation = "overlay";

	this.instance_2 = new lib.Group_2();
	this.instance_2.setTransform(183,197.1,0.7929,0.7929,0,0,0,27.1,14.2);
	this.instance_2.alpha = 0.2813;
	this.instance_2.compositeOperation = "overlay";

	this.instance_3 = new lib.Group_3();
	this.instance_3.setTransform(52.25,186.6,0.7929,0.7929,0,0,0,22.4,27.3);
	this.instance_3.alpha = 0.2813;
	this.instance_3.compositeOperation = "overlay";

	this.instance_4 = new lib.Group_4();
	this.instance_4.setTransform(160.3,131.9,0.7929,0.7929,0,0,0,7.7,30.9);
	this.instance_4.alpha = 0.2813;
	this.instance_4.compositeOperation = "overlay";

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5E5DC").s().p("AADBMIgSgTIgZgjQgQgYgLggQgBAAAAAAQAAgBABAAQAAAAAAgBQAAAAABAAQA1gjA4gJIAVgCIgCASQgDAaAEAXIAGAWIgBACQglAbgVAvg");
	this.shape.setTransform(166.4866,162.4471,0.792,0.7919);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F5E5DC").s().p("Ag+BFQgRg/AKg/IADgMIAaAMQAdALAfABQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAABQANAoAkAhIACABIgDACIgLAGQgkATgiAGIgiAEIgQACIgBAAIgBgBg");
	this.shape_1.setTransform(173.8402,178.2703,0.792,0.7919);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F5E5DC").s().p("AgKAhIgZgMQAAAAAAAAQAAAAAAAAQgBgBABAAQAAgBAAAAQANggAYgYIAGgFIABgBIABABQAGAOASAWQADAEgBADIAAArQgYgBgWgKg");
	this.shape_2.setTransform(172.1614,168.7625,0.792,0.7919);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F5E5DC").s().p("AgsgWIAsgPQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAYAKAUAEQgOAhgfAcQgfgagNgig");
	this.shape_3.setTransform(181.6195,176.3252,0.792,0.7919);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F5E5DC").s().p("AgdA1QgIgDgXgMIgNgGIALgMQAbgaAMgjQAAgBAAgBQABAAAAAAQABgBAAAAQABAAABAAQArgBApgXIADgCIAFAdQAGA2gQA4QgBAAAAABQAAAAAAAAQAAABgBAAQAAAAAAAAQg0gDgmgPg");
	this.shape_4.setTransform(189.4542,178.2455,0.792,0.7919);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F5E5DC").s().p("AgLBQIgHgNQgPgagVgTIgMgJQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQALghgDgcIgEgdIAAgCIALACIAbAEQAwALAsAeQAAAAAAABQABAAAAAAQAAABAAABQAAAAAAABQgSAxglApIgQASIgHAGg");
	this.shape_5.setTransform(196.8256,162.3679,0.792,0.7919);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F5E5DC").s().p("AABBIQgmgcgygEIAIgSQAcg3AzgmQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQA8AwAaA/IABAAIgCAAIgKACQgoAHggAXIgCAAIgBAAg");
	this.shape_6.setTransform(181.6393,150.3944,0.792,0.7919);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F5E5DC").s().p("AgkAgIgCgUQgDgXAGgYQAAAAAAgBQAAAAABgBQAAAAAAAAQAAAAAAAAIABAAQApAEAgAUIgJAKIgTAYIgCACQgWAFgWAKg");
	this.shape_7.setTransform(176.7967,158.8439,0.792,0.7919);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F5E5DC").s().p("AAfAlIgKgEIgbgJQgEgCgDgEIgYghQARgLASgFIAigHIABAAIAAABQAKApgKAiIAAABg");
	this.shape_8.setTransform(186.738,158.9627,0.792,0.7919);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F5E5DC").s().p("AgjgCIABgDIAcgkQAZAUARAnQgkAXgkABg");
	this.shape_9.setTransform(191.124,168.9407,0.792,0.7919);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F5E5DC").s().p("AgKAeQgDgIgEgDQgDgCgIgBQgMAAgIgFQAFgJAIgFQAMgHgFgOQgDgLACgLQAFAAAHAFIAGADIACABIADACQAFACADgBQAGAAADgEQAFgFALgCIAEgBQACAMgEAKQgFANALAIQAJAEAGALQgLAEgKAAQgJABgEACQgDADgDAJQgDAJgHAHQgHgIgDgJg");
	this.shape_10.setTransform(181.6987,166.7432,0.792,0.7919);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#F5E5DC").s().p("AADBMIgSgTIgZgjQgQgWgMgiQAAAAAAAAQAAAAAAgBQABAAAAAAQAAAAABgBQA0giA5gJIAVgDIgCASQgDAYAEAZIADAOIACAIQABAAAAABQAAAAAAAAQAAABgBAAQAAAAAAABQglAbgVAug");
	this.shape_11.setTransform(28.8473,109.271,0.792,0.7919);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F5E5DC").s().p("Ag+BFQgRhBAKg9IADgMIAaAMQAcALAgABQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAABQAOAqAjAfIACACIgOAIQghASglAHIgiAEIgQABIgCgBg");
	this.shape_12.setTransform(36.184,125.109,0.792,0.7919);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#F5E5DC").s().p("AgKAhIgYgLQgBgBAAAAQAAAAAAAAQgBgBAAAAQAAgBABAAQAPgiAWgVIAHgHIABABQAIASAQASQADACAAAGIAAAeIAAAMQgYAAgXgLg");
	this.shape_13.setTransform(34.5331,115.5864,0.792,0.7919);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F5E5DC").s().p("AgsgWIAsgPIACAAQAUAJAXAFQgNAiggAbQgggcgMggg");
	this.shape_14.setTransform(43.9831,123.1688,0.792,0.7919);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#F5E5DC").s().p("AgdA0IgfgOIgNgGIgBgBIADgCIAJgJQAbgbAMgjQAAgBABAAQAAgBABAAQAAAAABgBQAAAAABAAQApAAArgXIACgCIAFAdQAHA3gQA3QAAAAAAABQgBAAAAAAQAAAAAAABQgBAAAAAAQgzgDgngQg");
	this.shape_15.setTransform(51.8078,125.109,0.792,0.7919);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#F5E5DC").s().p("AgSBDQgOgZgXgUIgIgHIgDgCQgBAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQAKgkgCgZIgEgeIAAgBIAKABIAbAFQAxAKAsAeQAAABAAAAQABABAAAAQAAABAAAAQAAABAAABQgTAxgkApIgXAYg");
	this.shape_16.setTransform(59.1968,109.2314,0.792,0.7919);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#F5E5DC").s().p("AABBIQgmgbgxgFIAHgSQAcg1AygoIADAAQA7AxAaA+IAAAAIgBABIgKABQgpAIgfAWIgCAAIgBAAg");
	this.shape_17.setTransform(44.0029,97.2374,0.792,0.7919);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#F5E5DC").s().p("AgjAfQgDgLAAgIQgCgZAFgWIABgCIABAAQAqADAfAVIgdAkQgaAGgTAJg");
	this.shape_18.setTransform(39.1578,105.7074,0.792,0.7919);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#F5E5DC").s().p("AAfAmIgKgFQgOgFgMgEQgGgBgCgEIgSgZIgGgIQARgLATgGIAhgHIABAAIAAABQAKApgKAiIAAABg");
	this.shape_19.setTransform(49.1016,105.7866,0.792,0.7919);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#F5E5DC").s().p("AgigCIAAgDIAcgkQAaAWARAlQglAWgkACg");
	this.shape_20.setTransform(53.4876,115.7843,0.792,0.7919);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#F5E5DC").s().p("AgLAeQgCgIgDgDQgEgCgJAAQgJAAgLgGQAGgJAJgFQAGgEACgFQABgEgDgIQgDgLACgLQAEAAAJAFIAIAEIACACQAJAFAIgIQAEgDAMgEIAEgBQACALgEALQgEAOALAGQAHAEAGALQgJAFgKAAQgKABgEACQgDADgDAJQgDAIgHAIQgGgHgFgKg");
	this.shape_21.setTransform(44.0821,113.585,0.792,0.7919);

	this.instance_5 = new lib.Group_7();
	this.instance_5.setTransform(26.4,159.75,0.7929,0.7929,0,0,0,8.5,50);
	this.instance_5.alpha = 0.2813;
	this.instance_5.compositeOperation = "overlay";

	this.instance_6 = new lib.Group_8();
	this.instance_6.setTransform(111.45,197.8,0.7929,0.7929,0,0,0,31.6,15);
	this.instance_6.alpha = 0.2813;
	this.instance_6.compositeOperation = "overlay";

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2D1B17").s().p("ABICSQgwgPgYgMQgogTgVgcQgOgSgKgcQgFgPgJgjIgfh+IAZAWQAUBBAvA1QAuAzA/AbIAaALQAOAHAIAIQAKALACAOQABAPgJAJQgIAIgPAAQgLAAgRgFg");
	this.shape_22.setTransform(24.4151,200.1917,0.7923,0.7921);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2D1B17").s().p("AibCrQBwgmBMhgQBOhhAJh0QASAGAKAUQAKASgCAVQgBASgIAUQgGANgNAXQghA3geAlQgmAugpAdQhAAthIACg");
	this.shape_23.setTransform(162.2821,63.5585,0.792,0.7919);

	this.instance_7 = new lib.Group_11();
	this.instance_7.setTransform(110.3,104.7,0.7929,0.7929,0,0,0,54.8,22.5);
	this.instance_7.alpha = 0.5703;
	this.instance_7.compositeOperation = "overlay";

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#F5E5DC").s().p("AhdEYQg3gDhWgeQhjgigogHQgRgDgHgDQgIgEgFgFQgDgDgHgSQgDgIgshHQgdguAHgiIADgLQABgFgBgFQgBgIgIgJIgPgPQgLgNgCgRQgCgSAIgOQAIgPAPgIQAQgJAQACQgVgKgLgWQgLgXAHgWQAMggBXgPQAkgGBVgGQA9gDBVAnQBkAvAnAGQA4AJBJgaQAqgPBSgnQA0gXAhgIQA8gOAaATQAOAKADAVQAEAZAFAHQANAWALAJIAgAXQANAKgBAWQgBAMgEAaQgCAXAEAyQADAqgEAZQgGAdgPAXQgUAggpAjQgQANg5AqQhSA8iMAHIgQAAQg2AAingKg");
	this.shape_24.setTransform(108.4916,96.4376,0.7923,0.7921);

	this.instance_8 = new lib.Group_13();
	this.instance_8.setTransform(114,122.75,0.7929,0.7929,0,0,0,50.2,27.8);
	this.instance_8.alpha = 0.5703;
	this.instance_8.compositeOperation = "overlay";

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2D1B17").s().p("AvvLDQgXgEgrgJQCDgfAegMQBXghAphDQArhHAah7QAOg9ATiQIAgj+QARiQAHhvQABgPgEiCQgDhcAPgvQgDAJEQAUQENATAqgEQBZgIA0gMQA5gOAhgRQAsgYAWgnQAnBaAUA9QAZBQAHBNIAzHqQAIBLAQCfQARCMAhBZICnAuQBkAbBHgJQBBgHBHhDQBShNAqgSQgkAQgsBNQgxBUgiAUQg7AihfACQhUAChKgWQhRgYhHhBQgegdhXhnQgfgngVgVQgfgfgegTQg8glhVAPQhgAZgxAIQhkAQhkgTIhRgSQgygMgfgEQhigNg9AqQglAZgbAyQgMAWgeBIQgjBWg4A4QhEBEhQACIgKABQgaAAgggFg");
	this.shape_25.setTransform(123.9633,156.9789,0.7923,0.7921);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2D1B17").s().p("ACUEiQgogGgmgOQgqgRgcgXQgrgkgwhJQgyhVgaglQgshAgNgRQghgsgjgaQAPgXA4g6QAwgxgBgIQAUDCCDCdQCCCeC6A4QgQgFg0AMQgsAJgWAAIgLgBg");
	this.shape_26.setTransform(67.3767,54.461,0.7923,0.7921);

	this.instance_9 = new lib.Group_16();
	this.instance_9.setTransform(110.1,17.45,0.7929,0.7929,0,0,0,33.8,9.9);
	this.instance_9.alpha = 0.9297;
	this.instance_9.compositeOperation = "overlay";

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#F5E5DC").s().p("AhcCcQhEgUg/gmQhzhFhOh6QBMgfBYgUQCCgfB8AAQDIAACpBQIArAXIADACQgtBQhCA6QhJBAhVAaQg3ASg7AAQg9AAhBgUg");
	this.shape_27.setTransform(116.2289,23.5465,0.7923,0.7921);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#EE7768").s().p("AjAWFQoZg8kZlIQjQj0galeQgVkgBllcQBMkFCFkJQBEiFA6hbQBaiMBphrQCKiNCVhFIAdgMQBOB6BzBFQA+AnBEAUQB+AlBzgjQBVgaBIhAQBDg7AthRQDCBuCADxQBOCTB4FnQBLDjAnCQQBFEBAVDUQAKBfAABbQAAGyjmDoQh3B4i1A8QhrAkjiAjQixAbirAAQh0AAhygMg");
	this.shape_28.setTransform(108.3514,128.8825,0.792,0.7919);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2D1B17").s().p("AjOYrQkkggjihtQjihsici2QjqkSgemJQgWk3BrlxQBPkQCLkVQBHiLA9hfQBzizCJiAQCIiACThEIAagMQCjhDC5gUQEughD3B2QARAIAhASQB0BBBaBgQBaBgBKCJQA5BpA5CVQAiBaA/C/QBNDoApCWQBHEIAWDdQAfE7hADwQhADvifCgQiLCLjMBGQhRAbhmAUQg7AMh3ATQi5Aci3AAQh7AAh4gNgAia2bQhYAVhMAfIgdAMQiVBFiKCNQhpBrhaCMQg6BbhECFQiFEJhMEFQhlFcAVEgQAaFeDQD0QEZFIIZA8QEYAfEqguQDigjBrgkQC1g8B3h4QDmjoAAmyQAAhbgKhfQgVjUhFkBQgniQhLjjQh4lnhOiTQiAjxjChuIgDgCIgsgWQiohQjIAAQh8AAiCAeg");
	this.shape_29.setTransform(108.3552,125.623,0.792,0.7919);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.instance_9},{t:this.shape_26},{t:this.shape_25},{t:this.instance_8},{t:this.shape_24},{t:this.instance_7},{t:this.shape_23},{t:this.shape_22},{t:this.instance_6},{t:this.instance_5},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.4,217.9,252.20000000000002);


(lib.Head = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group_33();
	this.instance.setTransform(91.6,139.9,0.7932,0.7932,0,0,0,11.7,10);
	this.instance.alpha = 0.1914;
	this.instance.compositeOperation = "overlay";

	this.instance_1 = new lib.Group_1_1();
	this.instance_1.setTransform(68.15,197.7,0.7932,0.7932,0,0,0,11.7,9.4);
	this.instance_1.alpha = 0.1914;
	this.instance_1.compositeOperation = "overlay";

	this.instance_2 = new lib.Group_2_1();
	this.instance_2.setTransform(89,186.85,0.7932,0.7932,0,0,0,17.9,16.4);
	this.instance_2.alpha = 0.2813;
	this.instance_2.compositeOperation = "overlay";

	this.instance_3 = new lib.Group_3_1();
	this.instance_3.setTransform(87,161.35,0.7932,0.7932,0,0,0,14.1,13.6);
	this.instance_3.alpha = 0.2813;
	this.instance_3.compositeOperation = "overlay";

	this.instance_4 = new lib.Group_4_1();
	this.instance_4.setTransform(72.05,140.05,0.7932,0.7932,0,0,0,14.6,12.3);
	this.instance_4.alpha = 0.2813;
	this.instance_4.compositeOperation = "overlay";

	this.instance_5 = new lib.Group_5();
	this.instance_5.setTransform(52.55,180,0.7932,0.7932,0,0,0,15.2,9.9);
	this.instance_5.alpha = 0.2813;
	this.instance_5.compositeOperation = "overlay";

	this.instance_6 = new lib.Group_6_0();
	this.instance_6.setTransform(45.95,156.75,0.7932,0.7932,0,0,0,13.8,12.8);
	this.instance_6.alpha = 0.2813;
	this.instance_6.compositeOperation = "overlay";

	this.instance_7 = new lib.Group_7_0();
	this.instance_7.setTransform(97.7,159.95,0.7932,0.7932,0,0,0,16.9,16.8);
	this.instance_7.alpha = 0.2813;
	this.instance_7.compositeOperation = "overlay";

	this.instance_8 = new lib.Group_8_1();
	this.instance_8.setTransform(89.3,195.3,0.7932,0.7932,0,0,0,21.8,10.2);
	this.instance_8.alpha = 0.2813;
	this.instance_8.compositeOperation = "overlay";

	this.instance_9 = new lib.Group_9();
	this.instance_9.setTransform(50.05,188,0.7932,0.7932,0,0,0,19.8,14.5);
	this.instance_9.alpha = 0.2813;
	this.instance_9.compositeOperation = "overlay";

	this.instance_10 = new lib.Group_10_0();
	this.instance_10.setTransform(67.95,130.25,0.7932,0.7932,0,0,0,16.1,8.4);
	this.instance_10.alpha = 0.2813;
	this.instance_10.compositeOperation = "overlay";

	this.instance_11 = new lib.Group_11_1();
	this.instance_11.setTransform(35.25,154.8,0.7932,0.7932,0,0,0,13.3,14.7);
	this.instance_11.alpha = 0.2813;
	this.instance_11.compositeOperation = "overlay";

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#180F0D").s().p("AgfAoQgRgHgIgOQgUghAXgSQAVgPAkAEQAmADAQASQATAVgbAbIgCACQgRAQgdABIgDAAQgQAAgOgFg");
	this.shape.setTransform(66.4826,164.2378,0.7923,0.7921);

	this.instance_12 = new lib.Group_1_0();
	this.instance_12.setTransform(62.15,178.5,0.7929,0.7929,0,0,0,17.2,15.4);
	this.instance_12.alpha = 0.6289;
	this.instance_12.compositeOperation = "overlay";

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6D655C").s().p("AAAAYIgkgRQAKgVAPgNQAUgTASANQAFAEADAIQADALgDAUIgEAeQAAgCgfgOg");
	this.shape_1.setTransform(58.292,152.8278,0.7923,0.7921);

	this.instance_13 = new lib.Group_3_0();
	this.instance_13.setTransform(71.55,164.7,0.7929,0.7929,0,0,0,27.1,30.6);
	this.instance_13.alpha = 0.5508;
	this.instance_13.compositeOperation = "overlay";

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EE7768").s().p("ABcHgQgsgpgLhQQgagEggAWQgPAKgjAfQgcAagJAGQgUARgUAKQhDAihNgJQhTgKgug2QgagegIgoQgKgnAKgmQANg6AagqQAggzAvgUQguAEgrgUQgYgMgzglQgsgggRg2QgSg1ANg1QANgyAzgiQAuggA4gGQA9gIBFAIQA0AFAVAEQAxAKAPARQhHhVAbhoQAchsBzgLQAigEAzAQQApAMAoAUQAvAWAXAaQAbAfAFAtQAFAxgQAvQgPAwghAiQAggfBJgLQA6gIA7AGQA4AFAhAQQAsAWARAsQAWA5AEAqQAHA2gXAsQgJAVgRASQguA0hDAJIAAAAIAAAAQAGgBAdAeQAXAYAKANQAXAbANAwQALAjgDAjQgCAmgSAeQgYArg2AZQgtAVg9AHQggADgdAAQh0AAg4g1g");
	this.shape_2.setTransform(65.209,160.7794,0.7923,0.7921);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6D655C").s().p("AiNBxQgMgYARgdQAKgZAYgmQA7hjAegRQAlgVAnAHQAlAGAXAcQAYAcAAAjQgBAnggAiQgUAWgoAQQguAQgVAJIgnAVQgZANgRACIgIAAQgbAAgMgXg");
	this.shape_3.setTransform(90.5107,137.7945,0.7925,0.7924);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6D655C").s().p("AhJB4QgVgFgMgpQgKggAAgcQABg/A4gnQAzgkBAAEQAQAGANAIQAlAYgGAhQgDASgOAJIgcAPQgtAZgjAsQgQAZgKANQgRAVgPAAIgGgBg");
	this.shape_4.setTransform(64.2798,196.3348,0.7925,0.7924);

	this.instance_14 = new lib.Group_0();
	this.instance_14.setTransform(92.9,281.35,0.7932,0.7932,0,0,0,15.2,12.4);
	this.instance_14.alpha = 0.5703;
	this.instance_14.compositeOperation = "overlay";

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#DE758B").s().p("AgcBtIgCAAIgBAAQgjgHgZgTQgOgLgJgNQgKgOgGgOQgTgvAggoQAdgjA4gOQAjgIAjAEQAlAFAaATQAdAVAGAnQAGAlgSAgQgSAfgiASQggARglABIgEAAQgLAAgQgCg");
	this.shape_5.setTransform(91.1783,280.0216,0.7925,0.7924);

	this.instance_15 = new lib.Group_2_0();
	this.instance_15.setTransform(174.75,302.3,0.7932,0.7932,0,0,0,36.8,8.8);
	this.instance_15.alpha = 0.5703;
	this.instance_15.compositeOperation = "overlay";

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2D1B17").s().p("AhIBIQhCgFhAgQQgogKgfgMQgegKgmgRIgEgDQgNgVAEgRQAFgVAcgKIAJgDIAAAAIAFAAIACAAIANAFQAaAMAcAKQAfAKAZAHQA0AMA2AGQApAEAggBICQgIIAggEIAjgHQAZgEAKgDIBOgUIAiANIABAAIgKAIIgBABIgJAHIgCACIAAAAIgNAIIAAAAIgeARQAAABgVAKQgmARguAPIgPAEQgcAIgmAIIgmAHIhdACIgugCg");
	this.shape_6.setTransform(172.998,300.8802,0.7925,0.7924);

	this.instance_16 = new lib.Group_4_0();
	this.instance_16.setTransform(96.55,259.25,0.7932,0.7932,0,0,0,28.8,17.9);
	this.instance_16.alpha = 0.5703;
	this.instance_16.compositeOperation = "overlay";

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#332521").s().p("ABfCkQhwgXgngHIgugIQhAgOgjgVIgLgHQhKgzAVg5QATgzBTgpQBPgnBagIQBigJA3AhIAMAIQAhAYAbAnQAbApAJApQAMA2gXAoIgQAWQgiAkhJAAQgSAAgUgCg");
	this.shape_7.setTransform(94.5711,257.8833,0.7925,0.7924);

	this.instance_17 = new lib.Group_6();
	this.instance_17.setTransform(65.1,233.5,0.7932,0.7932,0,0,0,5.9,35.4);
	this.instance_17.alpha = 0.5703;
	this.instance_17.compositeOperation = "overlay";

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2D1B17").s().p("AgnCuQgGiqALhfQARiGA6h0IABACQgWAtgNAkQgaBLgLBaQgMBcAFCiIAECrIABAJIgHing");
	this.shape_8.setTransform(63.3735,232.299,0.7925,0.7924);

	this.instance_18 = new lib.Group_8_0();
	this.instance_18.setTransform(161.25,263.4,0.7932,0.7932,0,0,0,126.8,73);
	this.instance_18.alpha = 0.5703;
	this.instance_18.compositeOperation = "overlay";

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F5E5DC").s().p("ACvLMQhhgBhugEQjkgKjpgiQlAgvkuhZIgBAAIgMgDIgbgYQhAifgUkDQgEg2gDhKIgEirQgFijAMhcQALhaAbhLQANgkAWgtQBAA7BfAWQBYATBfgQQAegEAXgHQB4DvC3DFQCrC5D1CmQD/CwEfBvIAGACIhPAVQgKADgYAEIgjAGIggAFIiRAIQggAAgpgEQg3gGgygMQgZgGgggLQgbgJgbgMIgNgGIgCAAIgEAAIgBAAIgIAEQgdAJgFAVQgEARANAVIAFAFQAlARAeAKQAgALAnAKQBAAQBCAGIAtACIBegCIAmgHQAngIAcgJIAOgEQAugOAmgSQAVgJABgBIAegSIAAAAIAMgIIABAAIACgCIAJgHIABgBIAJgIQFlCDFxAWIjLAlIAAAAItpBNgAt+B6Qg4ANgdAjQggAoATAwQAGAOAKAPQAJAMAOALQAZATAjAHIABAAIACAAQATADANAAQAlgCAggRQAigSASgfQASgfgGgnQgGgmgdgVQgagUglgFQgMgBgMAAQgXAAgYAGgAssjXQhbAIhQAnQhTApgTAzQgVA6BLAyIAKAGQAjAWBAAOIAvAIQAmAHByAWQBmAMAqgtIARgWQAXgogNg1QgJgqgbgpQgagngigYIgMgIQgrgahFAAQgTAAgVACg");
	this.shape_9.setTransform(159.4931,262.0136,0.7925,0.7924);

	this.instance_19 = new lib.Group_10();
	this.instance_19.setTransform(201.6,299.5,0.7932,0.7932,0,0,0,1.3,1.2);
	this.instance_19.alpha = 0.5703;
	this.instance_19.compositeOperation = "overlay";

	this.instance_20 = new lib.Group_11_0();
	this.instance_20.setTransform(90.3,272.45,0.7932,0.7932,0,0,0,1.3,1.2);
	this.instance_20.alpha = 0.5703;
	this.instance_20.compositeOperation = "overlay";

	this.instance_21 = new lib.Group_12();
	this.instance_21.setTransform(197.85,302.35,0.7932,0.7932,0,0,0,1.2,1.2);
	this.instance_21.alpha = 0.5703;
	this.instance_21.compositeOperation = "overlay";

	this.instance_22 = new lib.Group_13_0();
	this.instance_22.setTransform(62.15,226.3,0.7932,0.7932,0,0,0,1.9,1.6);
	this.instance_22.alpha = 0.5703;
	this.instance_22.compositeOperation = "overlay";

	this.instance_23 = new lib.Group_14();
	this.instance_23.setTransform(90.4,289.95,0.7932,0.7932,0,0,0,1.3,1.2);
	this.instance_23.alpha = 0.5703;
	this.instance_23.compositeOperation = "overlay";

	this.instance_24 = new lib.Group_15();
	this.instance_24.setTransform(65.55,206.7,0.7932,0.7932,0,0,0,1.4,1.5);
	this.instance_24.alpha = 0.5703;
	this.instance_24.compositeOperation = "overlay";

	this.instance_25 = new lib.Group_16_0();
	this.instance_25.setTransform(188.3,303.35,0.7932,0.7932,0,0,0,1.2,1.3);
	this.instance_25.alpha = 0.5703;
	this.instance_25.compositeOperation = "overlay";

	this.instance_26 = new lib.Group_17();
	this.instance_26.setTransform(72.7,305.55,0.7932,0.7932,0,0,0,1.4,1.2);
	this.instance_26.alpha = 0.5703;
	this.instance_26.compositeOperation = "overlay";

	this.instance_27 = new lib.Group_18();
	this.instance_27.setTransform(82.35,284,0.7932,0.7932,0,0,0,1.2,1.5);
	this.instance_27.alpha = 0.5703;
	this.instance_27.compositeOperation = "overlay";

	this.instance_28 = new lib.Group_19();
	this.instance_28.setTransform(150.4,296.55,0.7932,0.7932,0,0,0,1.5,1.6);
	this.instance_28.alpha = 0.5703;
	this.instance_28.compositeOperation = "overlay";

	this.instance_29 = new lib.Group_20();
	this.instance_29.setTransform(151.55,296.85,0.7932,0.7932,0,0,0,1.4,1.4);
	this.instance_29.alpha = 0.5703;
	this.instance_29.compositeOperation = "overlay";

	this.instance_30 = new lib.Group_21();
	this.instance_30.setTransform(197.95,298.5,0.7932,0.7932,0,0,0,1.2,1.4);
	this.instance_30.alpha = 0.5703;
	this.instance_30.compositeOperation = "overlay";

	this.instance_31 = new lib.Group_22();
	this.instance_31.setTransform(79.6,266.05,0.7932,0.7932,0,0,0,1.8,1.4);
	this.instance_31.alpha = 0.5703;
	this.instance_31.compositeOperation = "overlay";

	this.instance_32 = new lib.Group_23();
	this.instance_32.setTransform(115.65,268.3,0.7932,0.7932,0,0,0,1.2,0.9);
	this.instance_32.alpha = 0.5703;
	this.instance_32.compositeOperation = "overlay";

	this.instance_33 = new lib.Group_24();
	this.instance_33.setTransform(179.1,307.55,0.7932,0.7932,0,0,0,1.2,1.2);
	this.instance_33.alpha = 0.5703;
	this.instance_33.compositeOperation = "overlay";

	this.instance_34 = new lib.Group_25();
	this.instance_34.setTransform(185.55,298.85,0.7932,0.7932,0,0,0,1.7,1.4);
	this.instance_34.alpha = 0.5703;
	this.instance_34.compositeOperation = "overlay";

	this.instance_35 = new lib.Group_26();
	this.instance_35.setTransform(109.7,248.8,0.7932,0.7932,0,0,0,1.2,1.4);
	this.instance_35.alpha = 0.5703;
	this.instance_35.compositeOperation = "overlay";

	this.instance_36 = new lib.Group_27();
	this.instance_36.setTransform(200.35,300.35,0.7932,0.7932,0,0,0,1.3,1.2);
	this.instance_36.alpha = 0.5703;
	this.instance_36.compositeOperation = "overlay";

	this.instance_37 = new lib.Group_28();
	this.instance_37.setTransform(153.05,304.6,0.7932,0.7932,0,0,0,1.4,1.1);
	this.instance_37.alpha = 0.5703;
	this.instance_37.compositeOperation = "overlay";

	this.instance_38 = new lib.Group_29();
	this.instance_38.setTransform(168.55,301.4,0.7932,0.7932,0,0,0,1.2,1.3);
	this.instance_38.alpha = 0.5703;
	this.instance_38.compositeOperation = "overlay";

	this.instance_39 = new lib.Group_30();
	this.instance_39.setTransform(176.9,301.6,0.7932,0.7932,0,0,0,1.2,1.5);
	this.instance_39.alpha = 0.5703;
	this.instance_39.compositeOperation = "overlay";

	this.instance_40 = new lib.Group_31();
	this.instance_40.setTransform(172.65,308.15,0.7932,0.7932,0,0,0,1.2,1.2);
	this.instance_40.alpha = 0.5703;
	this.instance_40.compositeOperation = "overlay";

	this.instance_41 = new lib.Group_32();
	this.instance_41.setTransform(149.6,296.65,0.7932,0.7932,0,0,0,1.9,1.7);
	this.instance_41.alpha = 0.5703;
	this.instance_41.compositeOperation = "overlay";

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#DE758B").s().p("AhYBSQhDgsAZhCQAFgOALgQQATgbAhgOQAfgNAiABQAiACAdAOQAmARAUAiIAIARQALAegIAfQgIAhgZASQgXARgdAGQgUAEgTAAQg0AAgvgeg");
	this.shape_10.setTransform(258.687,280.0581,0.7925,0.7924);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2D1B17").s().p("AAKAKIghgMIAZgGIADgBIAFgBQAPgCgBAIIgCADIAAABIgEADIgHAIg");
	this.shape_11.setTransform(200.3614,296.7233,0.7925,0.7924);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#332521").s().p("AjoCJIgHgHQgKgLgGgLQgUgkAHgwIAAgBIAEgSIABgBIACgHIAAgBIADgIIAAAAQAGgQAKgSIADgGIABgDIALgQIAAAAIAGgJIALgNQAYgdAcgRQAtgbBLABQBEABBJAYQBIAXAuAlQAyAnAAApIAAABIgBAGQgFAtg/AnIgXAMQgXAKgWAGIhNAPQhbAWg3AHQgYADgUAAQhCAAghgdg");
	this.shape_12.setTransform(258.6823,257.8672,0.7925,0.7924);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2D1B17").s().p("EAXEAh6IgugDQitgOgVg2IgBgDQgFgPAQhOQAQhPAUg5QARg0ALgCQhVAKhzAaIjHAuQklBBldAMQk8ALlJgiQkpgViigSQkhghiahDIgTgJQgegPgZgSIBnEsQADAKjpAUQjsAVgigKQgmgKgZgSQgcgTgZgiQgggqgdhFQgKgVgihbIgCgHQhlkLhHl1QiCqhBQonQBhqfGSmxQByh6CRhlIAggWQhihvgfiGQgiiPA3h8QA5h9BxhAQBog6CFACQB/ACB6A3QB8A4BTBfQBWBjAIB8QJMh3IOB0QAIgnARgoQAHg1AXgzQA6iBB2hAQBsg6CKAGQB/gGB2BEQB1A4BOBaQB2CGgbCvQgZChiBB6QDoCpCmD3QCYDiBmEvIAZBNQCJG2gCGkIgBAuQgKHpibHpQhND2hyDsQgzBshuAhQg6AShdAAQgmAAgqgDgA2wKcQgLBfAGCqQAHDMAGBTQALCgAdB7QAQBCAXA7IABACQAGAPAGAIIAGAFIACABIALADIASAOQIMCUIqAWQBrAFBeAAIABAAQBuABB7gFQE7gMFEgzIABAAQBhgPBqgVQCLgaCNgiIAEgFIAOgRQAIgKABgIIAMhJQAvkoANkkQAEhZABhkIAAgDQgBjpgfjxQgcjUg5j6IgOg8QgaAiggAzIgSAfQgsBRgYAnQgoBFgmAuIgNAPIgCADIgeAfIgSATIgYAWIgnAjIiQBpIhaA1IAAAAIAAAAQAXgOAzhiIBDiDQAUgfAchGQAchFATgdQAIgNAIgLIgNAIQlVC5lRAeQhgAJicgGQijgGgsAAQh1gBhaAOIgBAAQgqAGg1AaQgoAUhYA6Qg2AkgUALIhCAmIgDACIghARIgBAAIghAQIgCACIglAQIhHAaIgiAKIg4AMQhfAPhYgVQhfgXhAg9IgGANIgBgBQg7B0gRCGg");
	this.shape_13.setTransform(176.0657,172.1285,0.7925,0.7924);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#F5E5DC").ss(1,1,1,3,true).p("AAAgWIAAAt");
	this.shape_14.setTransform(352.3736,214.2127,0.7925,0.7924);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#F5E5DC").s().p("Ag8PlIAAAAIhhgCIBoAAIAAAAINohMIABAAIDLgmQlygVlkiDIAHgIIAEgEIAAgBIACgDQABgIgPACIgFABIgDABIgaAGIgFgCQkehvkBiwQj0iniri5Qi3jEh5jvQgWAGgfAFQheAQhYgUQhfgVhAg8IAGgMQBAA9BfAXQBYAVBfgQIAxgKIAHgCIAhgJIBHgaIAlgRIADgBIAhgQIAAgBIAhgRIADgCIBDglQAUgMA2gkQBYg6AngTQA2gaAqgHIABAAQA9gJBhABICfAEQArAAA2gCQCcAFBfgJQFRgeFWi6IgEAQQgTAegcBGQgcBFgTAfQg2BPgZAoQgsBEgUA5IBbg2IB/haIBjhaIAdggIADgCIAMgPQBbhrA3iBIATgfQAKACAZgPQAZgPAMACQA4D8AcDUQAgDxAADpIAAADQgBBigEBaQgMEjgvEpIgMBIQgCAIgIALIgOARIgEAFQiMAhiLAbQhqAUhhAPIgBAAQlEAzk7ANQhvAEhkAAIgXAAgAO/GYQghAOgTAaQgLAQgFAPQgZBCBDAsQBAApBLgPQAdgGAXgQQAZgTAIggQAIgggLgfIgIgQQgUgigmgSQgdgOgigBIgFAAQggAAgdAMgANfBYQgcARgYAcIgLAOIgGAIIAAABIgLAQIgBACIgDAGQgKATgGAPIAAABIgDAIIAAABIgCAIIgBABIgEASIAAAAQgHAxAUAkQAHAMAJAKIAHAGQAsAmBjgMQA3gGBcgWIBNgQQAWgFAXgLIAXgMQA/gmAFgtIABgHIAAAAQAAgqgygoQgugkhIgYQhJgXhFgBIgGAAQhHAAgrAag");
	this.shape_15.setTransform(177.6911,239.8347,0.7925,0.7924);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#F5E5DC").s().p("AAfBsIgCgBIgGgFQgGgHgGgQIgBgCQgWg7gQhBQgHgegGghQAWBxAiBVIAbAXg");
	this.shape_16.setTransform(66.7141,294.9868,0.7925,0.7924);

	this.instance_42 = new lib.Group_42();
	this.instance_42.setTransform(239.1,261.3,0.7932,0.7932,0,0,0,1.3,1.7);
	this.instance_42.alpha = 0.5508;
	this.instance_42.compositeOperation = "overlay";

	this.instance_43 = new lib.Group_43();
	this.instance_43.setTransform(274.7,259.95,0.7932,0.7932,0,0,0,1.4,1.7);
	this.instance_43.alpha = 0.5508;
	this.instance_43.compositeOperation = "overlay";

	this.instance_44 = new lib.Group_44();
	this.instance_44.setTransform(243.75,251.7,0.7932,0.7932,0,0,0,1,1);
	this.instance_44.alpha = 0.5508;
	this.instance_44.compositeOperation = "overlay";

	this.instance_45 = new lib.Group_45();
	this.instance_45.setTransform(242.85,252.9,0.7932,0.7932,0,0,0,1.2,1.4);
	this.instance_45.alpha = 0.5508;
	this.instance_45.compositeOperation = "overlay";

	this.instance_46 = new lib.Group_46();
	this.instance_46.setTransform(290.4,236.55,0.7932,0.7932,0,0,0,1.7,1.4);
	this.instance_46.alpha = 0.5508;
	this.instance_46.compositeOperation = "overlay";

	this.instance_47 = new lib.Group_47();
	this.instance_47.setTransform(282,259.35,0.7932,0.7932,0,0,0,1.2,1.6);
	this.instance_47.alpha = 0.5508;
	this.instance_47.compositeOperation = "overlay";

	this.instance_48 = new lib.Group_48();
	this.instance_48.setTransform(250.15,272.45,0.7932,0.7932,0,0,0,1.2,1.2);
	this.instance_48.alpha = 0.5508;
	this.instance_48.compositeOperation = "overlay";

	this.instance_49 = new lib.Group_49();
	this.instance_49.setTransform(264.6,279.25,0.7932,0.7932,0,0,0,1.3,1.4);
	this.instance_49.alpha = 0.5508;
	this.instance_49.compositeOperation = "overlay";

	this.instance_50 = new lib.Group_50();
	this.instance_50.setTransform(239.15,260.15,0.7932,0.7932,0,0,0,1.2,1.7);
	this.instance_50.alpha = 0.5508;
	this.instance_50.compositeOperation = "overlay";

	this.instance_51 = new lib.Group_51();
	this.instance_51.setTransform(267.9,268.5,0.7932,0.7932,0,0,0,1.2,1);
	this.instance_51.alpha = 0.5508;
	this.instance_51.compositeOperation = "overlay";

	this.instance_52 = new lib.Group_52();
	this.instance_52.setTransform(282.65,298.4,0.7932,0.7932,0,0,0,1.2,1.4);
	this.instance_52.alpha = 0.5508;
	this.instance_52.compositeOperation = "overlay";

	this.instance_53 = new lib.Group_53();
	this.instance_53.setTransform(193.1,314.8,0.7932,0.7932,0,0,0,0.9,1.4);
	this.instance_53.alpha = 0.5508;
	this.instance_53.compositeOperation = "overlay";

	this.instance_54 = new lib.Group_54();
	this.instance_54.setTransform(240.05,258.1,0.7932,0.7932,0,0,0,1.3,1.2);
	this.instance_54.alpha = 0.5508;
	this.instance_54.compositeOperation = "overlay";

	this.instance_55 = new lib.Group_55();
	this.instance_55.setTransform(241.65,254.7,0.7932,0.7932,0,0,0,1.5,1.3);
	this.instance_55.alpha = 0.5508;
	this.instance_55.compositeOperation = "overlay";

	this.instance_56 = new lib.Group_56();
	this.instance_56.setTransform(241.4,254.95,0.7932,0.7932,0,0,0,1.6,1.2);
	this.instance_56.alpha = 0.5508;
	this.instance_56.compositeOperation = "overlay";

	this.instance_57 = new lib.Group_57();
	this.instance_57.setTransform(242.4,253.55,0.7932,0.7932,0,0,0,1.2,1.5);
	this.instance_57.alpha = 0.5508;
	this.instance_57.compositeOperation = "overlay";

	this.instance_58 = new lib.Group_58();
	this.instance_58.setTransform(239.55,259.7,0.7932,0.7932,0,0,0,1.3,1.6);
	this.instance_58.alpha = 0.5508;
	this.instance_58.compositeOperation = "overlay";

	this.instance_59 = new lib.Group_59();
	this.instance_59.setTransform(239.75,258.95,0.7932,0.7932,0,0,0,1.3,1.5);
	this.instance_59.alpha = 0.5508;
	this.instance_59.compositeOperation = "overlay";

	this.instance_60 = new lib.Group_60();
	this.instance_60.setTransform(239.5,197.9,0.7932,0.7932,0,0,0,8.2,13.3);
	this.instance_60.alpha = 0.5508;
	this.instance_60.compositeOperation = "overlay";

	this.instance_61 = new lib.Group_61();
	this.instance_61.setTransform(119.8,203.1,0.7932,0.7932,0,0,0,1,0.9);
	this.instance_61.alpha = 0.5508;
	this.instance_61.compositeOperation = "overlay";

	this.instance_62 = new lib.Group_62();
	this.instance_62.setTransform(117.2,204.55,0.7932,0.7932,0,0,0,1.4,1);
	this.instance_62.alpha = 0.5508;
	this.instance_62.compositeOperation = "overlay";

	this.instance_63 = new lib.Group_63();
	this.instance_63.setTransform(128.5,191.8,0.7932,0.7932,0,0,0,1.2,1.3);
	this.instance_63.alpha = 0.5508;
	this.instance_63.compositeOperation = "overlay";

	this.instance_64 = new lib.Group_64();
	this.instance_64.setTransform(238.55,203.45,0.7932,0.7932,0,0,0,1.4,1.1);
	this.instance_64.alpha = 0.5508;
	this.instance_64.compositeOperation = "overlay";

	this.instance_65 = new lib.Group_65();
	this.instance_65.setTransform(253.55,171.65,0.7932,0.7932,0,0,0,2.4,2.5);
	this.instance_65.alpha = 0.5508;
	this.instance_65.compositeOperation = "overlay";

	this.instance_66 = new lib.Group_66();
	this.instance_66.setTransform(114.7,206.2,0.7932,0.7932,0,0,0,1.8,1.4);
	this.instance_66.alpha = 0.5508;
	this.instance_66.compositeOperation = "overlay";

	this.instance_67 = new lib.Group_67();
	this.instance_67.setTransform(70.6,304.9,0.7932,0.7932,0,0,0,1.4,1.2);
	this.instance_67.alpha = 0.5508;
	this.instance_67.compositeOperation = "overlay";

	this.instance_68 = new lib.Group_68();
	this.instance_68.setTransform(242.35,201.25,0.7932,0.7932,0,0,0,1.4,1.3);
	this.instance_68.alpha = 0.5508;
	this.instance_68.compositeOperation = "overlay";

	this.instance_69 = new lib.Group_69();
	this.instance_69.setTransform(97.85,212.2,0.7932,0.7932,0,0,0,1.3,1.2);
	this.instance_69.alpha = 0.5508;
	this.instance_69.compositeOperation = "overlay";

	this.instance_70 = new lib.Group_70();
	this.instance_70.setTransform(111.65,207.8,0.7932,0.7932,0,0,0,1.4,1.9);
	this.instance_70.alpha = 0.5508;
	this.instance_70.compositeOperation = "overlay";

	this.instance_71 = new lib.Group_71();
	this.instance_71.setTransform(108.75,208.85,0.7932,0.7932,0,0,0,1.2,1.5);
	this.instance_71.alpha = 0.5508;
	this.instance_71.compositeOperation = "overlay";

	this.instance_72 = new lib.Group_72();
	this.instance_72.setTransform(102.95,211.05,0.7932,0.7932,0,0,0,1.1,1.4);
	this.instance_72.alpha = 0.5508;
	this.instance_72.compositeOperation = "overlay";

	this.instance_73 = new lib.Group_73();
	this.instance_73.setTransform(105.9,210.05,0.7932,0.7932,0,0,0,1.4,1.4);
	this.instance_73.alpha = 0.5508;
	this.instance_73.compositeOperation = "overlay";

	this.instance_74 = new lib.Group_74();
	this.instance_74.setTransform(203.8,298.05,0.7932,0.7932,0,0,0,1.3,1.5);
	this.instance_74.alpha = 0.5508;
	this.instance_74.compositeOperation = "overlay";

	this.instance_75 = new lib.Group_75();
	this.instance_75.setTransform(68.4,205.6,0.7932,0.7932,0,0,0,1.3,1.3);
	this.instance_75.alpha = 0.5508;
	this.instance_75.compositeOperation = "overlay";

	this.instance_76 = new lib.Group_76();
	this.instance_76.setTransform(70.2,304.5,0.7932,0.7932,0,0,0,1.3,1.1);
	this.instance_76.alpha = 0.5508;
	this.instance_76.compositeOperation = "overlay";

	this.instance_77 = new lib.Group_77();
	this.instance_77.setTransform(99.9,211.75,0.7932,0.7932,0,0,0,1.4,1.3);
	this.instance_77.alpha = 0.5508;
	this.instance_77.compositeOperation = "overlay";

	this.instance_78 = new lib.Group_78();
	this.instance_78.setTransform(245.85,198.7,0.7932,0.7932,0,0,0,0.9,0.9);
	this.instance_78.alpha = 0.5508;
	this.instance_78.compositeOperation = "overlay";

	this.instance_79 = new lib.Group_79();
	this.instance_79.setTransform(164.4,188.65,0.7932,0.7932,0,0,0,24,1.9);
	this.instance_79.alpha = 0.5508;
	this.instance_79.compositeOperation = "overlay";

	this.instance_80 = new lib.Group_80();
	this.instance_80.setTransform(203.55,298.45,0.7932,0.7932,0,0,0,1.3,1.4);
	this.instance_80.alpha = 0.5508;
	this.instance_80.compositeOperation = "overlay";

	this.instance_81 = new lib.Group_81();
	this.instance_81.setTransform(202.6,297.35,0.7932,0.7932,0,0,0,1.7,1.6);
	this.instance_81.alpha = 0.5508;
	this.instance_81.compositeOperation = "overlay";

	this.instance_82 = new lib.Group_82();
	this.instance_82.setTransform(66,292.7,0.7932,0.7932,0,0,0,1.2,1.4);
	this.instance_82.alpha = 0.5508;
	this.instance_82.compositeOperation = "overlay";

	this.instance_83 = new lib.Group_83();
	this.instance_83.setTransform(252.6,193.8,0.7932,0.7932,0,0,0,1.3,1.4);
	this.instance_83.alpha = 0.5508;
	this.instance_83.compositeOperation = "overlay";

	this.instance_84 = new lib.Group_84();
	this.instance_84.setTransform(249.3,196.3,0.7932,0.7932,0,0,0,1.2,1.3);
	this.instance_84.alpha = 0.5508;
	this.instance_84.compositeOperation = "overlay";

	this.instance_85 = new lib.Group_85();
	this.instance_85.setTransform(233.85,205.7,0.7932,0.7932,0,0,0,1.1,1.4);
	this.instance_85.alpha = 0.5508;
	this.instance_85.compositeOperation = "overlay";

	this.instance_86 = new lib.Group_86();
	this.instance_86.setTransform(255.85,190.8,0.7932,0.7932,0,0,0,1.7,1.5);
	this.instance_86.alpha = 0.5508;
	this.instance_86.compositeOperation = "overlay";

	this.instance_87 = new lib.Group_87();
	this.instance_87.setTransform(278.45,160.75,0.7932,0.7932,0,0,0,4.9,5.7);
	this.instance_87.alpha = 0.5508;
	this.instance_87.compositeOperation = "overlay";

	this.instance_88 = new lib.Group_88();
	this.instance_88.setTransform(268.8,175.45,0.7932,0.7932,0,0,0,9,12.4);
	this.instance_88.alpha = 0.5508;
	this.instance_88.compositeOperation = "overlay";

	this.instance_89 = new lib.Group_89();
	this.instance_89.setTransform(259.1,186.55,0.7932,0.7932,0,0,0,1.6,1);
	this.instance_89.alpha = 0.5508;
	this.instance_89.compositeOperation = "overlay";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_89},{t:this.instance_88},{t:this.instance_87},{t:this.instance_86},{t:this.instance_85},{t:this.instance_84},{t:this.instance_83},{t:this.instance_82},{t:this.instance_81},{t:this.instance_80},{t:this.instance_79},{t:this.instance_78},{t:this.instance_77},{t:this.instance_76},{t:this.instance_75},{t:this.instance_74},{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.shape_9},{t:this.instance_18},{t:this.shape_8},{t:this.instance_17},{t:this.shape_7},{t:this.instance_16},{t:this.shape_6},{t:this.instance_15},{t:this.shape_5},{t:this.instance_14},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.instance_13},{t:this.shape_1},{t:this.instance_12},{t:this.shape},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,0,353.7,344.4);


(lib.AnimatedDoll = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Head
	this.instance = new lib.Head("synched",0);
	this.instance.setTransform(122.15,230.35,0.6734,0.6735,14.9921,0,0,172.7,315.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY:315.6,rotation:14.9846},0).wait(1).to({regY:315.4,rotation:14.9241,x:122.25,y:230.25},0).wait(1).to({regX:172.8,rotation:14.7588,x:122.45},0).wait(1).to({regX:172.7,rotation:14.438,x:122.7},0).wait(1).to({regX:172.8,rotation:13.9081,x:123.3,y:230.2},0).wait(1).to({regX:172.7,regY:315.6,rotation:13.1191,x:123.95},0).wait(1).to({regY:315.4,rotation:12.0177,x:125.1,y:230},0).wait(1).to({rotation:10.551,x:126.5,y:229.95},0).wait(1).to({regX:172.8,rotation:8.6682,x:128.5,y:229.8},0).wait(1).to({regX:172.7,regY:315.5,rotation:6.3165,x:130.75,y:229.85},0).wait(1).to({regX:172.8,regY:315.4,rotation:3.4447,x:133.7,y:229.75},0).wait(1).to({regX:172.7,rotation:0.0013,x:137.15},0).wait(1).to({rotation:-3.4422,x:140.45},0).wait(1).to({rotation:-6.314,x:143.3,y:229.85},0).wait(1).to({regY:315.5,rotation:-8.6656,x:145.6,y:230.1},0).wait(1).to({rotation:-10.5472,x:147.5,y:230.2},0).wait(1).to({regX:172.6,regY:315.4,rotation:-12.0136,x:148.85},0).wait(1).to({regX:172.7,rotation:-13.1165,x:150,y:230.35},0).wait(1).to({regX:172.6,regY:315.3,rotation:-13.9068,x:150.7,y:230.3},0).wait(1).to({regY:315.4,rotation:-14.4358,x:151.25,y:230.4},0).wait(1).to({rotation:-14.7563,x:151.55,y:230.5},0).wait(1).to({rotation:-14.9216,x:151.75,y:230.45},0).wait(1).to({regY:315.5,rotation:-14.9821,x:151.8,y:230.5},0).wait(1).to({regX:172.3,regY:315.4,rotation:-14.9921,x:151.75,y:230.65},0).wait(1).to({rotation:-14.9859,x:151.85,y:230.7},0).wait(1).to({rotation:-14.9307,x:151.7},0).wait(1).to({rotation:-14.7859,x:151.6,y:230.6},0).wait(1).to({rotation:-14.5013,x:151.3,y:230.65},0).wait(1).to({regY:315.3,rotation:-14.0337,x:150.8,y:230.5},0).wait(1).to({regX:172.4,regY:315.4,rotation:-13.3348,x:150.2,y:230.6},0).wait(1).to({regX:172.3,regY:315.3,rotation:-12.3604,x:149.2,y:230.4},0).wait(1).to({regX:172.2,rotation:-11.0625,x:147.75,y:230.25},0).wait(1).to({rotation:-9.3977,x:146.2,y:230.15},0).wait(1).to({regY:315.4,rotation:-7.3179,x:144.15},0).wait(1).to({regX:172.3,rotation:-4.7761,x:141.7,y:230.1},0).wait(1).to({rotation:-1.7281,x:138.6,y:229.9},0).wait(1).to({regX:172.2,regY:315.2,rotation:1.7255,x:135.15,y:229.8},0).wait(1).to({regX:172.3,rotation:4.7737,x:132.15,y:229.85},0).wait(1).to({regX:172.2,rotation:7.3128,x:129.55,y:229.95},0).wait(1).to({regX:172.3,regY:315.3,rotation:9.3938,x:127.55,y:230.15},0).wait(1).to({regY:315.2,rotation:11.0599,x:125.9,y:230.1},0).wait(1).to({regY:315.4,rotation:12.3579,x:124.6,y:230.35},0).wait(1).to({regY:315.2,rotation:13.3313,x:123.65,y:230.2},0).wait(1).to({regY:315.3,rotation:14.0299,x:122.95,y:230.4},0).wait(1).to({rotation:14.4988,x:122.55,y:230.45},0).wait(1).to({regX:172.2,rotation:14.7834,x:122.15,y:230.4},0).wait(1).to({regX:172.4,rotation:14.9295,y:230.5},0).wait(1).to({rotation:14.9833,x:122.1,y:230.4},0).wait(1).to({regX:172.6,regY:315.4,rotation:14.9912,x:122.05,y:230.3},0).wait(1));

	// Trunk
	this.instance_1 = new lib.Trunk("synched",0);
	this.instance_1.setTransform(136.85,399.65,0.6736,0.6737,-4.9988,0,0,109,252.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({rotation:4.9975},24,cjs.Ease.cubicInOut).to({rotation:-4.9988},25,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(14.1,9.3,248.1,390.5);


(lib.animateddoll_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.AnimatedDoll("synched",0);
	this.instance.setTransform(88.65,165.45,0.6575,0.6502,0,0,0,139.4,249.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.animateddoll_2, new cjs.Rectangle(11.5,9.3,157.8,253.7), null);


// stage content:
(lib.EnTing_project = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [49,53,74];
	// timeline functions:
	this.frame_49 = function() {
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.button_4.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_6.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_6()
		{
			this.gotoAndPlay(5);
		}
		
		
		
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.button_4.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_13.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_13()
		{
			this.gotoAndPlay(50);
		}
		
		
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.button_1.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_14.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_14()
		{
			this.gotoAndPlay(1);
		}
		
		
		/* Click to Go to Web Page
		Clicking on the specified symbol instance loads the URL in a new browser window.
		
		Instructions:
		1. Replace http://www.adobe.com with the desired URL address.
		   Keep the quotation marks ("").
		*/
		
		this.movieClip_2.addEventListener("click", fl_ClickToGoToWebPage_4);
		
		function fl_ClickToGoToWebPage_4() {
			window.open("https://www.pexels.com/photo/plate-of-fries-and-burger-3219483/", "_blank");
		}
		
		/* Click to Go to Web Page
		Clicking on the specified symbol instance loads the URL in a new browser window.
		
		Instructions:
		1. Replace http://www.adobe.com with the desired URL address.
		   Keep the quotation marks ("").
		*/
		
		this.button_3.addEventListener("click", fl_ClickToGoToWebPage_5);
		
		function fl_ClickToGoToWebPage_5() {
			window.open("https://www.burgerking.com.sg/menu", "_blank");
		}
	}
	this.frame_53 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop(54);
		
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.button_4.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_12.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_12()
		{
			this.gotoAndPlay(54);
		}
	}
	this.frame_74 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop(75);
		
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop(75);
		
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop(75);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(49).call(this.frame_49).wait(4).call(this.frame_53).wait(21).call(this.frame_74).wait(1));

	// animated_doll_
	this.instance = new lib.animateddoll_2();
	this.instance.setTransform(294.55,348.2,1,1,0,0,0,95.2,133.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(54).to({_off:false},0).wait(21));

	// text_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgcAhQgHgIAAgKQAAgNAIgNQAJgOALgHQAMgIANAAQAJAAAEAEQAFAEAAAFQAAAHgGAHQgIAJgOAEQgJAEgSACIAAAHQgBAIAGAFQAFAGAJAAQAFAAAFgDQAHgCALgJIABACQgUAVgSAAQgNAAgGgIgAgEgaQgJAKgFARQAMgBAHgDQAMgFAFgGQAGgHgBgGQAAgEgCgCQgDgCgEAAQgIAAgKAJg");
	this.shape.setTransform(460.65,292.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgTAmIgEgBQgFAAgCAEIgCAAIAEgdIAEAAQAAAOAFAFQAGAGAIAAQAGAAAEgEQADgEAAgFIgBgHQgCgFgHgJQgIgJgCgEQgDgFABgEQAAgJAGgGQAGgGAJAAIAFABIAFACIAGABQAEAAADgEIADAAIgFAbIgEAAQAAgMgEgFQgFgFgHAAQgFAAgDADQgDADAAAEQABADABACQABADAEAFQALAMADAGQADAGABAGQgBAJgHAHQgIAHgKAAQgHAAgIgDg");
	this.shape_1.setTransform(452.7,292.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAJAnQgCgCAAgEIACgLIACgGQgLAPgKAGQgHAEgGAAQgHAAgEgFQgFgGAAgJQAAgOAIgPQAJgPANgJQAJgIAJAAQAFAAAEADQADADACAGIADgKIAOgCIgRA7IgCAIIAAACIABACIACABIADgBIAJgLIADACQgGAJgHAFQgGAFgGAAQgDAAgCgCgAgCgeQgJAIgHAOQgHAOAAAMQAAAGADADQADAEAEAAQAJAAALgOQAPgSAAgUQAAgIgDgDQgDgDgFAAQgGAAgFAFg");
	this.shape_2.setTransform(444.925,292.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgcAhQgHgIAAgKQAAgNAIgNQAIgOAMgHQALgIANAAQAKAAAFAEQAEAEAAAFQAAAHgGAHQgIAJgPAEQgIAEgSACIAAAHQAAAIAFAFQAFAGAJAAQAEAAAGgDQAHgCALgJIABACQgUAVgSAAQgNAAgGgIgAgDgaQgLAKgFARQAOgBAGgDQALgFAGgGQAFgHABgGQgBgEgCgCQgCgCgEAAQgKAAgIAJg");
	this.shape_3.setTransform(436.65,292.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgUA+QgCgDAAgDIADgNIAWhSIADgLQAAAAAAgBQAAAAAAgBQAAAAgBgBQAAAAAAAAQgCgCgDAAIgGABIAAgEIAdgEIgdBnIgCAJIABADIACABIAEgBQADgFAFgHIADADQgJAMgGAEQgFAEgEAAQgEAAgCgCg");
	this.shape_4.setTransform(430.525,290.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgzA7IABgEQAHAAADgCQAEgDADgKIAWhNIACgJQAAAAAAgBQAAAAAAgBQgBAAAAgBQAAAAgBAAIgDgBIgIAAIAAgEIAdgEIgFAUQAJgLAIgFQAHgEAHAAQAJAAAFAGQAGAGgBAKQAAAUgPATQgQATgVABIgGgBIgIgEIgHAXIgCAJIABADQABAAAAABQAAAAABAAQAAABABAAQAAAAABAAIAJAAIgBAEgAAIgnQgIALgFAOIgHAaQAFAGAJAAQAEAAAFgDQAFgDAEgFQAFgEADgGQAEgGACgKQAEgIAAgJQAAgHgEgEQgDgDgEAAQgKAAgJALg");
	this.shape_5.setTransform(421.75,294.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgTAmIgEgBQgFAAgBAEIgDAAIAEgdIAEAAQABAOAEAFQAFAGAJAAQAGAAAEgEQAEgEgBgFIgBgHQgCgFgHgJQgIgJgCgEQgCgFAAgEQgBgJAHgGQAGgGAJAAIAFABIAFACIAHABQADAAADgEIADAAIgFAbIgEAAQABgMgGgFQgEgFgHAAQgFAAgDADQgCADAAAEQgBADACACQABADAEAFQALAMADAGQAEAGAAAGQAAAJgIAHQgIAHgKAAQgHAAgIgDg");
	this.shape_6.setTransform(410.2,292.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgcAhQgHgIAAgKQAAgNAIgNQAIgOAMgHQAMgIANAAQAJAAAEAEQAFAEAAAFQAAAHgGAHQgIAJgOAEQgJAEgSACIAAAHQgBAIAGAFQAFAGAJAAQAFAAAFgDQAHgCALgJIABACQgUAVgSAAQgNAAgGgIgAgEgaQgJAKgFARQANgBAGgDQAMgFAFgGQAGgHAAgGQAAgEgDgCQgCgCgEAAQgKAAgJAJg");
	this.shape_7.setTransform(403.15,292.725);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgRA4QgDgCAAgDIADgLIALgnIADgMIgBgDIgEgBIgIABIAAgDIAdgFIgQA8IgCAIIABACIACABIACgBQAFgEAFgIIADACQgGAJgHAHQgGAEgFAAQgEAAgCgCgAAGgqQgDgDAAgDQAAgEADgDQACgCAEAAQAEAAACACQADADAAAEQAAADgDADQgCACgEAAQgEAAgCgCg");
	this.shape_8.setTransform(396.825,290.975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgiAoIARg2QADgJAAgEIgCgDIgEgBIgHAAIgBgDIAdgFIgLAqQAOgZANgLQAHgGAEAAQABAAABAAQAAAAABABQAAAAABAAQAAAAABABQACACAAADQAAAGgDAFQgCAEgEAAIgEgBIgCgEIgBgDIgBAAIgDAAIgHAHQgHAJgIANIgGANIgEAMIgDALg");
	this.shape_9.setTransform(390.825,292.625);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag2BOQgDgCAAgDQAAgDACgCQACgCAEAAIAEACQAAAAAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAABQgBAAAAABQAAAAgBABIgBACIABABIACAAQAEAAAEgCQAEgCADgFQAEgFADgJIAGgYIAPg7IgPAAIABgGIALgBQADgBABgCQACgDAEgIQAFgLAFgFQAHgIAHgEQAHgEAGAAQAHAAAEAEQAEADAAADQAAAEgCACQgCACgDAAQgBAAAAAAQgBAAgBAAQAAgBgBAAQAAAAgBgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAIABgEIABgCIgBgCIgDgBQgGAAgEADQgGAFgFAKIgIAZIANAAIgCAGIgNAAIgJAmQgGAZgGAOQgKAUgKAHQgIAGgIAAQgGAAgDgEg");
	this.shape_10.setTransform(384.675,292.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAKA+QgCgCAAgEIADgOIAKgjIACgKIgBgDIgDgBQgDAAgDACQgFAEgIAJIgNAWQgEAGgDAIIgFASIgOAAIAdhkIAEgLIgCgEQgCgBgDAAIgEAAIgDAAIAAgEIAegEIgYBUQAPgXAJgIQAJgIAIAAQAEAAADADQADADAAAEQAAAGgDAIIgKAlIgCAHIAAACIACABIADgBQAFgFAFgGIACACIgIAKQgFAGgEACQgDACgEAAQgDAAgCgCg");
	this.shape_11.setTransform(512.65,268.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgTAxQgDgCAAgEQAAgEADgKIAPgyIgOAAIABgEQAJgCAHgFQAGgGAIgNIADAAIgHAYIAOAAIgBAGIgOAAIgOAzIgDALIABACIACABQACAAAEgDIAIgLIADACQgIAMgGAFQgGADgEAAQgEAAgCgDg");
	this.shape_12.setTransform(506.4,269.675);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgRA4QgDgCAAgDIADgLIALgnIADgMIgBgDIgEgBIgIABIAAgDIAdgFIgQA8IgCAIIABACIACABIACgBQAFgEAFgIIADACQgGAJgHAHQgGAEgFAAQgEAAgCgCgAAGgqQgDgDAAgDQAAgEADgDQACgCAEAAQAEAAACACQADADAAAEQAAADgDADQgCACgEAAQgEAAgCgCg");
	this.shape_13.setTransform(501.175,269.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAJApIgFg8IgjA8IgFAAQAAgmgDgUQgCgJgDgDQgCgCgFAAIgGAAIAAgDIAagGQAFAPABAdIABAPIAjg7IAEAAIAFBBQAQgSAJgPQAFgJABgEIgBgDIgEgDIgDgDIAAgDQAAgBAAgBQAAAAAAgBQAAAAABgBQAAAAAAgBQACgCAEAAQADAAACADQADADAAAEIgBAJQgDAHgIAMIgTAaIgOARg");
	this.shape_14.setTransform(492.45,270.775);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgiAoIARg2QADgJAAgEIgCgDIgEgBIgHAAIgBgDIAdgFIgLAqQAOgZANgLQAHgGAEAAQABAAABAAQAAAAABABQAAAAABAAQAAAAABABQACACAAADQAAAGgDAFQgCAEgEAAIgEgBIgCgEIgBgDIgBAAIgDAAIgHAHQgHAJgIANIgGANIgEAMIgDALg");
	this.shape_15.setTransform(478.675,270.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgcAhQgHgIAAgKQAAgNAIgNQAJgOALgHQAMgIANAAQAJAAAEAEQAFAEAAAFQAAAHgGAHQgIAJgOAEQgJAEgSACIAAAHQgBAIAGAFQAFAGAJAAQAFAAAFgDQAHgCALgJIABACQgUAVgSAAQgNAAgGgIgAgEgaQgJAKgFARQAMgBAHgDQAMgFAFgGQAGgHgBgGQAAgEgCgCQgDgCgEAAQgIAAgKAJg");
	this.shape_16.setTransform(471,270.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgfA5QgKgDgEgEQgDgFAAgFQAAgDACgEQADgEAEgDIANgIQgEgDAAgEQAAgDADgEQAEgEAMgEQgKgCgGgGQgGgGAAgIQAAgNAMgJQAKgKASAAQAGAAAEABQAEABAFADIAYAAIgEAJIgOAAIACAJQAAAMgKAJQgKAJgQABQgJADgGADQAAAAAAAAQAAABgBAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQABABAAAAQAAAAAAABQACABAGACIAQAEQAPADAEAEQAEAFABAGQgBAHgEAGQgGAGgKAEQgKADgMAAQgLAAgIgCgAghAdQgDAFgBAFQAAAFAGAEQAHAGAOAAQAMAAAJgFQAJgEAAgHQAAgDgDgDQgEgDgJgCIgagHQgIAEgDAFgAgKgsQgHAKAAALQAAAGAEAFQAEAEAGAAQAEAAAEgDQAFgCADgFQACgEACgHIACgKQAAgHgEgEQgEgEgGAAQgKAAgFAKg");
	this.shape_17.setTransform(462.3,272.625);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgiAoIARg2QADgJAAgEIgCgDIgEgBIgHAAIgBgDIAdgFIgLAqQAOgZANgLQAHgGAEAAQABAAABAAQAAAAABABQAAAAABAAQAAAAABABQACACAAADQAAAGgDAFQgCAEgEAAIgEgBIgCgEIgBgDIgBAAIgDAAIgHAHQgHAJgIANIgGANIgEAMIgDALg");
	this.shape_18.setTransform(455.325,270.675);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAJAnQgBgCAAgDIAAgIIAIgbQgOAXgKAKQgKAJgIAAQgFAAgCgDQgDgDAAgEQAAgHAEgNIAHgaIAEgNIgBgBIgCgBQAAAAgBAAQAAAAgBAAQAAAAgBABQAAAAgBAAIgIAKIgCgCQAGgKAHgFQAGgEAEAAQAEAAACACQACACAAAEQAAAEgDANIgJAbIgDAPIABACIADABQADAAAFgDQAEgCAHgKQAHgKAGgIQAEgJAHgTIABgHIAOAAIgPA0IgEAOIABADIABABIADgCIAJgLIADACQgHALgHAGQgFADgEAAQgEAAgCgCg");
	this.shape_19.setTransform(447,270.775);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("Ag2A8IABgEIAJgBQAEgCABgCIAGgPIAVhIQADgJAAgDQAAgEgDgBQgCgCgHAAIgDAAIACgEIApAAQALABAIADQAJADAEAGQAEAGAAAGQAAALgHAIQgIAIgRAFQALADAFAGQAFAHAAAIQAAAJgEAIQgFAIgHAFQgHAEgKACQgHACgPAAgAgXA0IAPABQAMAAALgJQALgIAAgNQAAgMgHgFQgGgGgOAAIgHAAgAAHg0IgNAuIAHAAQATAAAJgIQAJgHAAgNQAAgIgGgFQgFgGgMAAIgIABg");
	this.shape_20.setTransform(436.625,268.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgTAmIgFgBQgEAAgCAEIgCAAIAFgdIADAAQAAAOAGAFQAEAGAJAAQAGAAAEgEQAEgEAAgFIgBgHQgDgFgHgJQgIgJgCgEQgCgFgBgEQABgJAGgGQAGgGAJAAIAFABIAGACIAFABQAEAAADgEIADAAIgFAbIgEAAQAAgMgEgFQgFgFgGAAQgGAAgDADQgDADAAAEQAAADACACQABADADAFQAMAMADAGQADAGAAAGQAAAJgHAHQgIAHgLAAQgFAAgJgDg");
	this.shape_21.setTransform(423.2,270.775);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAJAnQgBgCAAgDIAAgIIAIgbQgOAXgKAKQgKAJgIAAQgFAAgCgDQgDgDAAgEQAAgHAEgNIAHgaIAEgNIgBgBIgCgBQAAAAgBAAQAAAAgBAAQAAAAgBABQAAAAgBAAIgIAKIgCgCQAGgKAHgFQAGgEAEAAQAEAAACACQACACAAAEQAAAEgDANIgJAbIgDAPIABACIADABQADAAAFgDQAEgCAHgKQAHgKAGgIQAEgJAHgTIABgHIAOAAIgPA0IgEAOIABADIABABIADgCIAJgLIADACQgHALgHAGQgFADgEAAQgEAAgCgCg");
	this.shape_22.setTransform(415.5,270.775);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AggA5QgJgDgDgEQgFgFAAgFQABgDACgEQADgEADgDIAOgIQgEgDAAgEQAAgDAEgEQADgEALgEQgJgCgGgGQgFgGAAgIQgBgNALgJQAMgKAQAAQAHAAAFABQADABAEADIAYAAIgCAJIgPAAIABAJQAAAMgJAJQgKAJgRABQgIADgFADQgBAAAAAAQAAABgBAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQABABAAAAQAAAAABABQABABAHACIAPAEQAOADAGAEQADAFABAGQAAAHgGAGQgFAGgKAEQgKADgMAAQgKAAgKgCgAghAdQgEAFAAAFQABAFAEAEQAIAGAOAAQANAAAIgFQAJgEAAgHQAAgDgDgDQgEgDgJgCIgagHQgHAEgEAFgAgLgsQgGAKAAALQAAAGAEAFQAEAEAGAAQADAAAFgDQAFgCACgFQADgEACgHIACgKQAAgHgEgEQgEgEgHAAQgIAAgHAKg");
	this.shape_23.setTransform(406.45,272.625);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAKAnQgCgCAAgDQAAgFADgKIAKgiIACgLIgBgCQAAgBgBAAQAAAAAAAAQgBgBAAAAQAAAAgBAAQgDAAgDADQgHAEgGAJQgHAJgHANQgFAHgCAJIgFAPIgMAAIAPg2IADgMQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAAAgBgBQAAAAAAAAQgBgBAAAAQgBAAAAAAQAAAAgBAAIgEAAIgDABIgBgDIAfgGIgMAoQAPgYAJgIQAJgIAIAAQAFAAADADQACADAAAFQAAAFgCAJIgLAkIgCAIIAAACIACAAIADgBQAFgDAFgIIACACQgHALgIAFQgFAEgEAAQgDAAgCgCg");
	this.shape_24.setTransform(397.3,270.775);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAGA9IABgDIACAAQAFAAAEgCQADgDABgDIACgNIABgPIghAAIgMAQIgFAIIgBAFQAAACACADQACACAGAAIgBADIgkAAIABgDQAHAAAFgFQAFgDAKgOIBGhgIADAAIgJBiIgBAKQAAADACABQABADADACIAKABIgBADgAgDAPIAdAAIAFgtg");
	this.shape_25.setTransform(386.475,268.55);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgdAhQgGgIAAgKQAAgNAIgNQAJgOAMgHQAKgIANAAQAKAAAEAEQAFAEAAAFQAAAHgGAHQgIAJgPAEQgIAEgSACIgBAHQABAIAFAFQAGAGAHAAQAFAAAHgDQAFgCAMgJIACACQgVAVgSAAQgNAAgHgIgAgEgaQgJAKgGARQANgBAIgDQAKgFAGgGQAFgHAAgGQABgEgDgCQgDgCgEAAQgJAAgJAJg");
	this.shape_26.setTransform(499.5,248.825);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAKAnQgCgCAAgDQAAgFADgKIAKgiIACgLIgBgCQAAgBgBAAQAAAAAAAAQgBgBAAAAQAAAAgBAAQgCAAgDADQgHAEgHAJQgGAJgIANQgEAHgDAJIgFAPIgMAAIAQg2IACgMQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAAAAAgBQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAgBAAIgEAAIgDABIgBgDIAfgGIgMAoQAQgYAIgIQAJgIAIAAQAFAAADADQACADAAAFQAAAFgCAJIgLAkIgCAIIABACIABAAIADgBQAEgDAGgIIADACQgIALgIAFQgFAEgEAAQgDAAgCgCg");
	this.shape_27.setTransform(490.65,248.825);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgeAhQgIgIAAgMQAAgNAHgMQAIgNAMgHQAMgIALAAQAMAAAIAIQAHAIAAAMQAAAMgHANQgHANgMAHQgNAIgLAAQgMAAgHgIgAgNgRQgLASAAASQAAAIAFAFQAEAEAGAAQAMAAALgSQAKgSAAgSQAAgJgEgEQgEgEgGAAQgMAAgLASg");
	this.shape_28.setTransform(481.775,248.825);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgiAoIARg2QADgJAAgEIgCgDIgEgBIgHAAIgBgDIAdgFIgLAqQAOgZANgLQAHgGAEAAQABAAABAAQAAAAABABQAAAAABAAQAAAAABABQACACAAADQAAAGgDAFQgCAEgEAAIgEgBIgCgEIgBgDIgBAAIgDAAIgHAHQgHAJgIANIgGANIgEAMIgDALg");
	this.shape_29.setTransform(469.675,248.725);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgcAhQgHgIAAgKQAAgNAIgNQAJgOALgHQAMgIANAAQAJAAAEAEQAFAEAAAFQAAAHgGAHQgIAJgOAEQgJAEgSACIAAAHQgBAIAGAFQAFAGAJAAQAFAAAFgDQAHgCALgJIABACQgUAVgSAAQgNAAgGgIgAgEgaQgJAKgFARQAMgBAHgDQAMgFAFgGQAGgHgBgGQAAgEgCgCQgDgCgEAAQgIAAgKAJg");
	this.shape_30.setTransform(462,248.825);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AACA+QgBgDAAgEQgBgEADgJIAEgLQgMAUgKAHQgIAGgHgBQgGABgFgHQgFgGAAgJQAAgNAJgQQAHgOAPgIQAKgIAIAAQAFAAADACQAEACADAFIAJggIACgEIAAgHIgBgCQgBgBAAAAQgBAAAAgBQgBAAAAAAQgBAAgBAAIgGABIAAgEIAegEIgeBmIgDAMIABABIACABIACgBQADgCAHgJIADACQgGAIgGAGQgHAFgFAAQgEABgCgCgAgTAEQgMATgBAQQAAAIAEADQADADADAAQAKAAANgTQANgVAAgNQAAgFgDgEQgDgEgFAAQgLAAgLARg");
	this.shape_31.setTransform(453.9,246.55);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgiAoIARg2QADgJAAgEIgCgDIgEgBIgHAAIgBgDIAdgFIgLAqQAOgZANgLQAHgGAEAAQABAAABAAQAAAAABABQAAAAABAAQAAAAABABQACACAAADQAAAGgDAFQgCAEgEAAIgEgBIgCgEIgBgDIgBAAIgDAAIgHAHQgHAJgIANIgGANIgEAMIgDALg");
	this.shape_32.setTransform(446.325,248.725);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgeAhQgIgIAAgMQAAgNAHgMQAIgNAMgHQAMgIALAAQAMAAAIAIQAHAIAAAMQAAAMgHANQgHANgMAHQgNAIgLAAQgMAAgHgIgAgNgRQgLASAAASQAAAIAFAFQAEAEAGAAQAMAAALgSQAKgSAAgSQAAgJgEgEQgEgEgGAAQgMAAgLASg");
	this.shape_33.setTransform(437.925,248.825);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgnA8IABgEIAKgBQAEgBACgDQADgEADgLIAUhHQACgJAAgEIgBgEQAAAAgBgBQAAAAAAgBQgBAAAAAAQgBAAAAgBIgJAAIACgDIAtAAIgBADQgGgBgDACQgEACgCADQgCADgDALIgUBHIgDANQAAAAAAABQAAAAABABQAAAAAAABQAAAAABABIACACIAKABIgBAEg");
	this.shape_34.setTransform(426.425,246.75);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgsA5QgCgCAAgDQAAgDADgDQADgDADAAIADABIACADIABACIABABIACgBQAFgDAHgHIAMgOIgFg2QgBgOgDgDQgCgDgGAAIgGAAIgBgDIAZgGIAEAJIACASIAEAqIAPgTIAMgSIAFgKIABgDIgBgCIgDgBQgDgBgBgCQgCgCAAgDQAAgEACgCQACgCADAAQAEAAADADQADADAAAGQAAAHgFAJQgFAJgNASQgOARgSAWQgNAPgHAEQgGAEgFAAQgDAAgCgCg");
	this.shape_35.setTransform(413.725,250.675);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAJAnQgCgCAAgEIACgLIACgGQgLAPgKAGQgHAEgGAAQgHAAgEgFQgFgGAAgJQAAgOAIgPQAJgPANgJQAJgIAJAAQAFAAAEADQADADACAGIADgKIAOgCIgRA7IgCAIIAAACIABACIACABIADgBIAJgLIADACQgGAJgHAFQgGAFgGAAQgDAAgCgCgAgCgeQgJAIgHAOQgHAOAAAMQAAAGADADQADAEAEAAQAJAAALgOQAPgSAAgUQAAgIgDgDQgDgDgFAAQgGAAgFAFg");
	this.shape_36.setTransform(405.925,248.825);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAEA8IABgEIADAAQAGAAAEgCQADgBACgEIAGgRIAThFIhEBhIgEAAIgLhhIgVBJIgDANQAAADADACQACACAJAAIgBAEIgnAAIABgEIACAAQAJAAAEgEQADgDADgLIAahXIgGgFIgKgBIABgDIAeAAIALBeIBEheIAdAAIAAADIgLABQgDABgCAEQgDADgDAJIgWBLQgCAGAAAFQAAADADABQADADAHAAIACAAIAAAEg");
	this.shape_37.setTransform(394.525,246.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},54).wait(21));

	// replay
	this.button_1 = new lib.button_1();
	this.button_1.name = "button_1";
	this.button_1.setTransform(66.55,33.55,1,1,0,0,0,48.5,18.5);
	this.button_1._off = true;
	new cjs.ButtonHelper(this.button_1, 0, 1, 2, false, new lib.button_1(), 3);

	this.timeline.addTween(cjs.Tween.get(this.button_1).wait(49).to({_off:false},0).to({_off:true},5).wait(21));

	// button_2_website_
	this.movieClip_2 = new lib.Symbol1();
	this.movieClip_2.name = "movieClip_2";
	this.movieClip_2.setTransform(71.5,88.05);
	this.movieClip_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.movieClip_2).wait(49).to({_off:false},0).to({_off:true},5).wait(21));

	// button_3_website_
	this.button_3 = new lib.button_website();
	this.button_3.name = "button_3";
	this.button_3.setTransform(73,116.85,1,1,0,0,0,53,45.1);
	this.button_3._off = true;
	new cjs.ButtonHelper(this.button_3, 0, 1, 2, false, new lib.button_website(), 3);

	this.timeline.addTween(cjs.Tween.get(this.button_3).wait(49).to({_off:false},0).to({_off:true},5).wait(21));

	// button_next
	this.button_4 = new lib.button_next();
	this.button_4.name = "button_4";
	this.button_4.setTransform(756.5,576.5,1,1,0,0,0,42.5,18.5);
	new cjs.ButtonHelper(this.button_4, 0, 1, 2, false, new lib.button_next(), 3);

	this.instance_1 = new lib.images();
	this.instance_1.setTransform(-2,0,2.9162,3.2788);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.button_4}]},49).to({state:[{t:this.button_4}]},4).to({state:[{t:this.instance_1}]},1).wait(21));

	// text_
	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgdA8QgDgDABgDQgBgEADgDQACgCAFAAQADAAACACQAEADAAAEQAAADgEADQgCACgDAAQgFAAgCgCgAgUAeQAAgLAFgIQAEgIALgMQAMgMADgIQADgGAAgGQAAgHgEgEQgFgFgIAAQgHAAgEADQgDACAAACIABAFIACAFQAAADgCACQgCACgEAAQgDAAgBgCQgCgCAAgEQgBgHAIgHQAHgGANAAQANAAAIAHQAJAIAAAKQgBAIgDAFQgGAIgOAKQgNAJgGAHQgEAIgEALg");
	this.shape_38.setTransform(440,408.125);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgfA5QgKgDgEgEQgDgFAAgFQgBgDADgEQACgEAFgDIANgIQgEgDAAgEQAAgDADgEQAEgEAMgEQgKgCgGgGQgGgGABgIQAAgNALgJQALgKARAAQAGAAAEABQAFABADADIAZAAIgEAJIgOAAIABAJQAAAMgJAJQgKAJgQABQgJADgGADQAAAAAAAAQAAABgBAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQABABAAAAQAAAAAAABQACABAGACIAQAEQAPADAEAEQAFAFAAAGQgBAHgFAGQgFAGgKAEQgKADgMAAQgKAAgJgCgAghAdQgDAFgBAFQAAAFAGAEQAHAGAOAAQAMAAAJgFQAJgEAAgHQAAgDgDgDQgEgDgJgCIgagHQgIAEgDAFgAgLgsQgGAKAAALQAAAGAEAFQAEAEAGAAQAEAAAEgDQAEgCAEgFQADgEABgHIACgKQAAgHgEgEQgEgEgGAAQgKAAgGAKg");
	this.shape_39.setTransform(430.45,412.075);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AAKAnQgCgCAAgDQAAgFADgKIAKgiQACgHAAgEIgBgCQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAQgDAAgDADQgGAEgHAJQgHAJgHANQgEAHgDAJIgEAPIgOAAIAQg2IADgMQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAAAgBgBQAAAAAAAAQgBgBAAAAQgBAAAAAAQgBAAAAAAIgEAAIgDABIAAgDIAdgGIgLAoQAQgYAJgIQAIgIAIAAQAEAAADADQADADAAAFQAAAFgDAJIgKAkIgCAIIAAACIACAAIADgBQAEgDAGgIIACACQgIALgHAFQgFAEgEAAQgDAAgCgCg");
	this.shape_40.setTransform(421.3,410.225);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgRA4QgDgCAAgDIADgLIALgnIADgMIgBgDIgEgBIgIABIAAgDIAdgFIgQA8IgCAIIABACIACABIACgBQAFgEAFgIIADACQgGAJgHAHQgGAEgFAAQgEAAgCgCgAAGgqQgDgDAAgDQAAgEADgDQACgCAEAAQAEAAACACQADADAAAEQAAADgDADQgCACgEAAQgEAAgCgCg");
	this.shape_41.setTransform(414.825,408.475);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgUA9QgCgCAAgDIADgNIAWhRIADgMQAAgBAAAAQAAAAAAgBQAAAAgBgBQAAAAAAgBQgCgBgDAAIgGABIAAgDIAdgGIgdBoIgCAKIABACIACABIAEgCQADgDAFgIIADADQgJAMgGAEQgFADgEAAQgEAAgCgCg");
	this.shape_42.setTransform(410.025,407.95);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgUA9QgCgCAAgDIADgNIAWhRIADgMQAAgBAAAAQAAAAAAgBQAAAAgBgBQAAAAAAgBQgCgBgDAAIgGABIAAgDIAdgGIgdBoIgCAKIABACIACABIAEgCQADgDAFgIIADADQgJAMgGAEQgFADgEAAQgEAAgCgCg");
	this.shape_43.setTransform(405.025,407.95);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgdAhQgGgIAAgKQAAgNAIgNQAIgOANgHQAKgIANAAQAKAAAFAEQAEAEAAAFQAAAHgGAHQgHAJgQAEQgIAEgSACIgBAHQABAIAFAFQAGAGAHAAQAGAAAGgDQAFgCAMgJIACACQgVAVgSAAQgNAAgHgIgAgDgaQgKAKgGARQANgBAIgDQAKgFAGgGQAFgHABgGQgBgEgCgCQgDgCgDAAQgKAAgIAJg");
	this.shape_44.setTransform(398.15,410.225);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgTAmIgFgBQgDAAgCAEIgEAAIAGgdIADAAQAAAOAGAFQAEAGAJAAQAGAAAEgEQADgEAAgFIAAgHQgDgFgHgJQgIgJgCgEQgDgFAAgEQAAgJAHgGQAGgGAJAAIAFABIAFACIAHABQAEAAACgEIAEAAIgGAbIgDAAQAAgMgGgFQgEgFgHAAQgFAAgDADQgCADAAAEQAAADABACQABADADAFQAMAMADAGQADAGAAAGQABAJgIAHQgIAHgLAAQgFAAgJgDg");
	this.shape_45.setTransform(390.2,410.225);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgcAhQgHgIAAgKQAAgNAIgNQAIgOAMgHQALgIAOAAQAJAAAFAEQAEAEAAAFQAAAHgGAHQgIAJgOAEQgJAEgSACIAAAHQgBAIAGAFQAFAGAJAAQAEAAAGgDQAHgCALgJIABACQgUAVgSAAQgNAAgGgIgAgDgaQgLAKgEARQANgBAGgDQALgFAGgGQAGgHAAgGQAAgEgDgCQgCgCgEAAQgKAAgIAJg");
	this.shape_46.setTransform(437,388.275);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgiAoIARg2QADgJAAgEIgCgDIgEgBIgHAAIgBgDIAdgFIgLAqQAOgZANgLQAHgGAEAAQABAAABAAQAAAAABABQAAAAABAAQAAAAABABQACACAAADQAAAGgDAFQgCAEgEAAIgEgBIgCgEIgBgDIgBAAIgDAAIgHAHQgHAJgIANIgGANIgEAMIgDALg");
	this.shape_47.setTransform(430.325,388.175);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AAJAnQgCgCAAgEIACgLIACgGQgLAPgKAGQgHAEgGAAQgHAAgEgFQgFgGAAgJQAAgOAIgPQAJgPANgJQAJgIAJAAQAFAAAEADQADADACAGIADgKIAOgCIgRA7IgCAIIAAACIABACIACABIADgBIAJgLIADACQgGAJgHAFQgGAFgGAAQgDAAgCgCgAgCgeQgJAIgHAOQgHAOAAAMQAAAGADADQADAEAEAAQAJAAALgOQAPgSAAgUQAAgIgDgDQgDgDgFAAQgGAAgFAFg");
	this.shape_48.setTransform(421.925,388.275);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AAJAnQgBgCgBgDIABgIIAIgbQgPAXgJAKQgJAJgJAAQgEAAgDgDQgDgDAAgEQAAgHAEgNIAIgaIADgNIgBgBIgCgBQgBAAAAAAQAAAAgBAAQAAAAgBABQAAAAgBAAIgIAKIgDgCQAHgKAHgFQAGgEAFAAQADAAACACQACACAAAEQAAAEgEANIgIAbIgDAPIABACIADABQADAAAEgDQAFgCAHgKQAIgKAFgIQAFgJAFgTIACgHIAOAAIgQA0IgDAOIABADIABABIADgCIAJgLIADACQgHALgHAGQgFADgFAAQgDAAgCgCg");
	this.shape_49.setTransform(408.5,388.275);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgeAhQgIgIAAgMQAAgNAHgMQAIgNAMgHQAMgIALAAQAMAAAIAIQAHAIAAAMQAAAMgHANQgHANgMAHQgNAIgLAAQgMAAgHgIgAgNgRQgLASAAASQAAAIAFAFQAEAEAGAAQAMAAALgSQAKgSAAgSQAAgJgEgEQgEgEgGAAQgMAAgLASg");
	this.shape_50.setTransform(399.425,388.275);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgsA5QgCgCAAgDQAAgDADgDQADgDADAAIADABIACADIABACIABABIACgBQAFgDAHgHIAMgOIgFg2QgBgOgDgDQgCgDgGAAIgGAAIgBgDIAZgGIAEAJIACASIAEAqIAPgTIAMgSIAFgKIABgDIgBgCIgDgBQgDgBgBgCQgCgCAAgDQAAgEACgCQACgCADAAQAEAAADADQADADAAAGQAAAHgFAJQgFAJgNASQgOARgSAWQgNAPgHAEQgGAEgFAAQgDAAgCgCg");
	this.shape_51.setTransform(390.225,390.125);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgTAxQgDgCAAgEQAAgEADgKIAPgyIgOAAIABgEQAJgCAHgFQAGgGAIgNIADAAIgHAYIAOAAIgBAGIgOAAIgOAzIgDALIABACIACABQACAAAEgDIAIgLIADACQgIAMgGAFQgGADgEAAQgEAAgCgDg");
	this.shape_52.setTransform(465.9,365.225);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AAJAnQgCgCAAgEIACgLIACgGQgLAPgKAGQgHAEgGAAQgHAAgEgFQgFgGAAgJQAAgOAIgPQAJgPANgJQAJgIAJAAQAFAAAEADQADADACAGIADgKIAOgCIgRA7IgCAIIAAACIABACIACABIADgBIAJgLIADACQgGAJgHAFQgGAFgGAAQgDAAgCgCgAgCgeQgJAIgHAOQgHAOAAAMQAAAGADADQADAEAEAAQAJAAALgOQAPgSAAgUQAAgIgDgDQgDgDgFAAQgGAAgFAFg");
	this.shape_53.setTransform(458.275,366.325);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AAKA9QgCgCAAgDIADgOIAKgkIACgJIgBgCIgDgBQgDAAgCACQgGADgIAJIgOAWQgDAGgCAHIgGASIgNAAIAdhjIACgLIgBgEQgCgCgDAAIgFABIgBAAIAAgEIAdgFIgYBVQAPgXAJgIQAJgIAIAAQAFAAADADQACADAAAFQAAAGgCAGIgLAlIgCAIIABACIACAAIACgBQAFgEAFgGIACABIgHALQgGAFgEACQgDACgDABQgEgBgCgCg");
	this.shape_54.setTransform(449.15,364.05);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgUAxQgCgCAAgEQAAgEACgKIAQgyIgOAAIABgEQAJgCAHgFQAFgGAIgNIAEAAIgGAYIANAAIgCAGIgNAAIgOAzIgCALIAAACIACABQACAAADgDIAJgLIADACQgIAMgHAFQgFADgFAAQgDAAgDgDg");
	this.shape_55.setTransform(442.9,365.225);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgiAoIARg2QADgJAAgEIgCgDIgEgBIgHAAIgBgDIAdgFIgLAqQAOgZANgLQAHgGAEAAQABAAABAAQAAAAABABQAAAAABAAQAAAAABABQACACAAADQAAAGgDAFQgCAEgEAAIgEgBIgCgEIgBgDIgBAAIgDAAIgHAHQgHAJgIANIgGANIgEAMIgDALg");
	this.shape_56.setTransform(432.175,366.225);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgcAhQgHgIAAgKQAAgNAIgNQAIgOAMgHQALgIANAAQAKAAAFAEQAEAEAAAFQAAAHgGAHQgIAJgOAEQgJAEgSACIAAAHQAAAIAFAFQAFAGAJAAQAEAAAGgDQAHgCALgJIABACQgUAVgSAAQgNAAgGgIgAgDgaQgLAKgFARQAOgBAGgDQALgFAGgGQAFgHABgGQgBgEgCgCQgCgCgEAAQgKAAgIAJg");
	this.shape_57.setTransform(424.5,366.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgfA5QgJgDgFgEQgEgFABgFQAAgDACgEQADgEADgDIAOgIQgEgDAAgEQAAgDADgEQAEgEALgEQgJgCgGgGQgGgGABgIQgBgNALgJQAMgKAQAAQAHAAAEABQAFABADADIAYAAIgCAJIgPAAIABAJQAAAMgJAJQgKAJgRABQgJADgEADQgBAAAAAAQAAABgBAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQABABAAAAQAAAAABABQABABAGACIAQAEQAOADAFAEQAFAFAAAGQAAAHgGAGQgFAGgKAEQgKADgMAAQgKAAgJgCgAghAdQgEAFAAAFQABAFAFAEQAHAGAOAAQANAAAIgFQAJgEAAgHQAAgDgDgDQgDgDgKgCIgagHQgIAEgDAFgAgLgsQgGAKAAALQAAAGAEAFQAEAEAGAAQADAAAFgDQAFgCADgFQADgEABgHIACgKQAAgHgEgEQgEgEgHAAQgIAAgHAKg");
	this.shape_58.setTransform(415.8,368.175);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgiAoIARg2QADgJAAgEIgCgDIgEgBIgHAAIgBgDIAdgFIgLAqQAOgZANgLQAHgGAEAAQABAAABAAQAAAAABABQAAAAABAAQAAAAABABQACACAAADQAAAGgDAFQgCAEgEAAIgEgBIgCgEIgBgDIgBAAIgDAAIgHAHQgHAJgIANIgGANIgEAMIgDALg");
	this.shape_59.setTransform(408.825,366.225);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AAJAnQgCgCAAgDIABgIIAIgbQgPAXgIAKQgKAJgJAAQgEAAgDgDQgDgDAAgEQAAgHAEgNIAIgaIACgNIAAgBIgCgBQgBAAAAAAQAAAAgBAAQAAAAgBABQAAAAgBAAIgIAKIgDgCQAHgKAHgFQAGgEAFAAQADAAACACQACACAAAEQAAAEgEANIgIAbIgDAPIABACIADABQADAAAEgDQAFgCAHgKQAIgKAFgIQAEgJAGgTIACgHIAOAAIgQA0IgDAOIABADIABABIADgCIAJgLIADACQgHALgHAGQgFADgFAAQgDAAgCgCg");
	this.shape_60.setTransform(400.5,366.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgnA1IAbhbIADgMQAAgBAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQgDgBgEAAIgFABIAAgEIAegFIgRA9QAJgIAFgEQAGgDAHAAQAKAAAGAGQAGAHAAAKQAAAOgIAOQgIAOgNAIQgLAIgLAAQgOAAgOgLgAgDgCQgIAFgDAMIgMAoQAJAEAHAAQAHAAAIgFQAIgGAGgOQAHgNAAgOQAAgHgFgEQgEgFgFAAQgIAAgHAHg");
	this.shape_61.setTransform(391.45,364.05);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AAKApIgHg8IgiA8IgEAAQgBgmgEgUQAAgJgDgDQgDgCgEAAIgHAAIAAgDIAagGQAEAPACAdIABAPIAjg7IADAAIAHBBQAPgSAJgPQAGgJgBgEIgBgDIgCgDIgEgDIgBgDQAAgBABgBQAAAAAAgBQAAAAABgBQAAAAABgBQACgCACAAQAEAAADADQACADAAAEIgBAJQgDAHgHAMIgTAaIgPARg");
	this.shape_62.setTransform(436.6,344.375);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgcAhQgHgIAAgKQAAgNAIgNQAIgOAMgHQALgIANAAQAKAAAFAEQAEAEAAAFQAAAHgGAHQgIAJgOAEQgJAEgSACIAAAHQgBAIAGAFQAFAGAJAAQAEAAAGgDQAHgCALgJIABACQgUAVgSAAQgNAAgGgIgAgDgaQgLAKgEARQANgBAGgDQALgFAGgGQAGgHAAgGQAAgEgDgCQgCgCgEAAQgKAAgIAJg");
	this.shape_63.setTransform(426.65,344.375);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AAKAnQgCgCAAgDQAAgFADgKIAKgiIACgLIgBgCQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAQgDAAgDADQgGAEgHAJQgHAJgHANQgFAHgCAJIgEAPIgOAAIAQg2IADgMQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAAAgBgBQAAAAAAAAQgBgBAAAAQgBAAAAAAQgBAAAAAAIgEAAIgDABIgBgDIAegGIgLAoQAPgYAKgIQAIgIAIAAQAFAAADADQACADAAAFQAAAFgCAJIgLAkIgCAIIAAACIACAAIADgBQAFgDAFgIIACACQgHALgIAFQgFAEgEAAQgDAAgCgCg");
	this.shape_64.setTransform(417.8,344.375);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgcAhQgHgIAAgKQAAgNAIgNQAIgOAMgHQALgIANAAQAKAAAFAEQAEAEAAAFQAAAHgGAHQgIAJgPAEQgIAEgSACIAAAHQAAAIAFAFQAFAGAJAAQAEAAAGgDQAHgCALgJIABACQgUAVgSAAQgNAAgGgIgAgDgaQgLAKgFARQAOgBAGgDQALgFAGgGQAFgHABgGQgBgEgCgCQgCgCgEAAQgKAAgIAJg");
	this.shape_65.setTransform(405.15,344.375);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AAKA9QgCgBAAgEIADgOIAKgkIACgJIgBgCIgDgBQgCAAgEABQgGAEgHAJIgOAWQgDAGgCAHIgGASIgOAAIAehjIACgLIgBgEQgCgCgDAAIgEABIgCAAIAAgEIAdgEIgYBUQAPgXAJgIQAJgIAIAAQAEAAAEADQACADAAAFQAAAGgCAGIgLAlIgCAIIAAACIADABIACgCQAFgEAFgGIACABIgIALQgFAGgEABQgDADgDAAQgEAAgCgDg");
	this.shape_66.setTransform(396.3,342.1);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgUAxQgCgCAAgEQAAgEACgKIAQgyIgOAAIABgEQAKgCAGgFQAFgGAJgNIADAAIgHAYIAOAAIgBAGIgOAAIgOAzIgDALIABACIACABQACAAADgDIAJgLIADACQgIAMgGAFQgFADgFAAQgEAAgDgDg");
	this.shape_67.setTransform(390.05,343.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgTAxQgDgCAAgEQAAgEADgKIAPgyIgOAAIABgEQAJgCAHgFQAFgGAJgNIADAAIgHAYIAOAAIgBAGIgOAAIgOAzIgDALIABACIACABQACAAADgDIAJgLIADACQgIAMgGAFQgGADgEAAQgEAAgCgDg");
	this.shape_68.setTransform(466.9,321.325);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AAJAnQgBgCgBgDIABgIIAIgbQgPAXgJAKQgJAJgJAAQgEAAgDgDQgDgDAAgEQAAgHAEgNIAIgaIADgNIgBgBIgCgBQgBAAAAAAQAAAAgBAAQAAAAgBABQAAAAgBAAIgIAKIgDgCQAHgKAHgFQAGgEAFAAQADAAACACQACACAAAEQAAAEgEANIgIAbIgDAPIABACIADABQADAAAEgDQAFgCAHgKQAIgKAFgIQAFgJAFgTIACgHIAOAAIgQA0IgDAOIABADIABABIADgCIAJgLIADACQgHALgHAGQgFADgFAAQgDAAgCgCg");
	this.shape_69.setTransform(459.35,322.425);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgeAhQgIgIAAgMQAAgNAHgMQAIgNAMgHQAMgIALAAQAMAAAIAIQAHAIAAAMQAAAMgHANQgHANgMAHQgNAIgLAAQgMAAgHgIgAgNgRQgLASAAASQAAAIAFAFQAEAEAGAAQAMAAALgSQAKgSAAgSQAAgJgEgEQgEgEgGAAQgMAAgLASg");
	this.shape_70.setTransform(450.275,322.425);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgnA2IAbhcIADgMQAAAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAAAQgDgCgDAAIgGABIAAgEIAegEIgRA8QAIgIAGgEQAGgDAHAAQAKAAAGAGQAGAHAAAKQAAAOgIAOQgIAOgNAIQgLAIgMAAQgNgBgOgJgAgDgCQgIAFgDAMIgLAoQAIAEAHAAQAIABAHgGQAIgGAGgNQAGgOABgNQAAgIgFgEQgEgFgFABQgIgBgHAHg");
	this.shape_71.setTransform(441.3,320.15);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AAJAnQgCgCAAgEIACgLIACgGQgLAPgKAGQgHAEgGAAQgHAAgEgFQgFgGAAgJQAAgOAIgPQAJgPANgJQAJgIAJAAQAFAAAEADQADADACAGIADgKIAOgCIgRA7IgCAIIAAACIABACIACABIADgBIAJgLIADACQgGAJgHAFQgGAFgGAAQgDAAgCgCgAgCgeQgJAIgHAOQgHAOAAAMQAAAGADADQADAEAEAAQAJAAALgOQAPgSAAgUQAAgIgDgDQgDgDgFAAQgGAAgFAFg");
	this.shape_72.setTransform(432.275,322.425);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgdAhQgGgIAAgKQAAgNAIgNQAJgOAMgHQALgIANAAQAJAAAEAEQAFAEAAAFQAAAHgGAHQgHAJgQAEQgIAEgSACIgBAHQAAAIAGAFQAGAGAHAAQAFAAAHgDQAFgCAMgJIACACQgVAVgSAAQgNAAgHgIgAgEgaQgKAKgFARQANgBAIgDQALgFAFgGQAFgHAAgGQABgEgDgCQgCgCgFAAQgIAAgKAJg");
	this.shape_73.setTransform(419.5,322.425);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgiAoIARg2QADgJAAgEIgCgDIgEgBIgHAAIgBgDIAdgFIgLAqQAOgZANgLQAHgGAEAAQABAAABAAQAAAAABABQAAAAABAAQAAAAABABQACACAAADQAAAGgDAFQgCAEgEAAIgEgBIgCgEIgBgDIgBAAIgDAAIgHAHQgHAJgIANIgGANIgEAMIgDALg");
	this.shape_74.setTransform(412.825,322.325);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgeAhQgIgIAAgMQAAgNAHgMQAIgNAMgHQAMgIALAAQAMAAAIAIQAHAIAAAMQAAAMgHANQgHANgMAHQgNAIgLAAQgMAAgHgIgAgNgRQgLASAAASQAAAIAFAFQAEAEAGAAQAMAAALgSQAKgSAAgSQAAgJgEgEQgEgEgGAAQgMAAgLASg");
	this.shape_75.setTransform(404.425,322.425);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AAeAnQgCgCAAgDQAAgFADgMIAIgcIAEgKIAAgEIgBgDIgDgBQgDAAgFADQgLAMgLATQgHANgFAVIgOAAIAQg0IABgMIAAgDQAAgBgBAAQAAAAAAAAQAAgBgBAAQAAAAAAAAQgDAAgDADQgGADgIALQgIALgFAKIgKAfIgOAAIARg4IACgIIAAgCIgBgDQAAgBgBAAQgBAAAAgBQgBAAAAAAQgBAAAAAAIgHABIgBgDIAegGIgLAoQAIgOAFgHQAJgLAHgFQAFgDAEAAQAEAAADADQADADABAEQgBAFgCAGIgGAWQAOgaANgLQAIgGAGAAQAFAAACADQADADgBAGIgBAKIgKAiIgDAMIABACIACABIACgCQAFgEAFgGIADACIgIAJQgFAGgEADQgEACgEAAQgDAAgCgCg");
	this.shape_76.setTransform(393.25,322.425);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AAEA9QgEgGgHgjIgNAKIgJAgIgNAAIAdhkIACgIIABgEQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAAAgBAAQgBgCgDAAIgHABIAAgEIAdgEIgYBVIALgJQAPgOAFgFIABgDIAAgCIgCgBIgGgBIgCAAIAAgDIAnAAIgBADIgLADQgFABgEADIgMAIIgIAHIAFASIAGAWQAAABABABQAAABABAAQAAABABAAQAAAAAAAAIAEgBQAFgEAFgIIADADQgKAMgEAEQgGADgEABQgDAAgCgDg");
	this.shape_77.setTransform(477,298.2);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgTAmIgEgBQgFAAgBAEIgDAAIAEgdIAEAAQABAOAEAFQAFAGAJAAQAGAAAEgEQAEgEgBgFIgBgHQgCgFgHgJQgIgJgCgEQgCgFAAgEQgBgJAHgGQAGgGAJAAIAFABIAFACIAHABQADAAADgEIADAAIgFAbIgEAAQABgMgGgFQgEgFgHAAQgFAAgDADQgCADAAAEQgBADACACQABADAEAFQALAMADAGQAEAGAAAGQAAAJgIAHQgIAHgKAAQgHAAgIgDg");
	this.shape_78.setTransform(468.7,300.475);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AAJAnQgCgCAAgEIACgLIACgGQgLAPgKAGQgHAEgGAAQgHAAgEgFQgFgGAAgJQAAgOAIgPQAJgPANgJQAJgIAJAAQAFAAAEADQADADACAGIADgKIAOgCIgRA7IgCAIIAAACIABACIACABIADgBIAJgLIADACQgGAJgHAFQgGAFgGAAQgDAAgCgCgAgCgeQgJAIgHAOQgHAOAAAMQAAAGADADQADAEAEAAQAJAAALgOQAPgSAAgUQAAgIgDgDQgDgDgFAAQgGAAgFAFg");
	this.shape_79.setTransform(460.925,300.475);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgnA8IABgEIAKgBQAEgCACgCQADgEADgLIAUhHQACgJAAgEIgBgEQAAAAgBgBQAAAAAAgBQgBAAAAAAQgBAAAAAAIgJgBIACgEIAtAAIgBAEQgGgBgDACQgEACgCADQgCADgDALIgUBHIgDANQAAAAAAABQAAAAABABQAAAAAAABQAAAAABABIACACIAKABIgBAEg");
	this.shape_80.setTransform(449.425,298.4);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgsA5QgCgCAAgDQAAgDADgDQADgDADAAIADABIACADIABACIABABIACgBQAFgDAHgHIAMgOIgFg2QgBgOgDgDQgCgDgGAAIgGAAIgBgDIAZgGIAEAJIACASIAEAqIAPgTIAMgSIAFgKIABgDIgBgCIgDgBQgDgBgBgCQgCgCAAgDQAAgEACgCQACgCADAAQAEAAADADQADADAAAGQAAAHgFAJQgFAJgNASQgOARgSAWQgNAPgHAEQgGAEgFAAQgDAAgCgCg");
	this.shape_81.setTransform(436.725,302.325);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AAJAnQgCgCAAgEIACgLIACgGQgLAPgKAGQgHAEgGAAQgHAAgEgFQgFgGAAgJQAAgOAIgPQAJgPANgJQAJgIAJAAQAFAAAEADQADADACAGIADgKIAOgCIgRA7IgCAIIAAACIABACIACABIADgBIAJgLIADACQgGAJgHAFQgGAFgGAAQgDAAgCgCgAgCgeQgJAIgHAOQgHAOAAAMQAAAGADADQADAEAEAAQAJAAALgOQAPgSAAgUQAAgIgDgDQgDgDgFAAQgGAAgFAFg");
	this.shape_82.setTransform(428.925,300.475);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AAEA8IABgEIADAAQAGAAAEgCQADgBACgEIAGgRIAThEIhEBgIgEAAIgLhgIgVBIIgDANQAAADADACQACACAJAAIgBAEIgnAAIABgEIACAAQAJAAAEgEQADgDADgLIAahYIgGgEIgKgBIABgEIAeAAIALBfIBEhfIAdAAIAAAEIgLABQgDABgCADQgDAEgDAKIgWBKIgCAKQAAAEADACQADACAHAAIACAAIAAAEg");
	this.shape_83.setTransform(417.525,298.4);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgRA4QgDgCAAgDIADgLIALgnIADgMIgBgDIgEgBIgIABIAAgDIAdgFIgQA8IgCAIIABACIACABIACgBQAFgEAFgIIADACQgGAJgHAHQgGAEgFAAQgEAAgCgCgAAGgqQgDgDAAgDQAAgEADgDQACgCAEAAQAEAAACACQADADAAAEQAAADgDADQgCACgEAAQgEAAgCgCg");
	this.shape_84.setTransform(402.825,298.725);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgEA8IACgEQAGAAACgBQADgCACgCQACgEAEgLIAKgkIg2AAIgLAkQgCAJAAAEQAAADACACQACACAJAAIgBAEIguAAIABgEQAHAAACgBQADgCACgCIAGgPIAVhHQACgJAAgEIgBgEQAAAAAAgBQgBAAAAgBQgBAAAAAAQgBAAAAAAIgJgBIABgEIAuAAIgBAEQgFgBgDACQgEACgCACQgDAFgDAKIgIAdIA2AAIAIgdQADgJAAgEIgBgEQAAAAgBgBQAAAAgBgBQAAAAgBAAQAAAAgBAAQgCgBgHAAIABgEIAwAAIgBAEQgGgBgDACQgEACgCACQgDAFgDAKIgVBHQgDAJAAAEQAAADADACQACACAJAAIgBAEg");
	this.shape_85.setTransform(394.075,298.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38}]},49).to({state:[]},5).wait(21));

	// girl_
	this.instance_2 = new lib.AnimatedDoll("synched",0);
	this.instance_2.setTransform(-145.5,330.05,0.6877,0.5749,0,0,0,111.6,134.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:111.7,x:276.5,mode:"independent"},49).to({_off:true},5).wait(21));

	// Background
	this.instance_3 = new lib.Tween3("synched",0);
	this.instance_3.setTransform(1215.5,301.7);

	this.instance_4 = new lib.Tween4("synched",0);
	this.instance_4.setTransform(399.5,301.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).to({state:[{t:this.instance_4}]},24).to({state:[]},30).wait(21));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({_off:true,x:399.5},24).wait(51));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(193,300,1437.1,303.4);
// library properties:
lib.properties = {
	id: '0B2A237233F88D44AFC235D6B8476AE4',
	width: 800,
	height: 600,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/EnTing_project_atlas_1.png?1713232943857", id:"EnTing_project_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['0B2A237233F88D44AFC235D6B8476AE4'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;